package com.example.pocolock

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка в шторке уведомлений. Выглядит как «Аэро» (самолётик). */
class LockTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile
        if (tile != null) {
            tile.label = "Aero"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_aero)
            tile.state = Tile.STATE_INACTIVE
            tile.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        LockAction.run(this)
    }
}
