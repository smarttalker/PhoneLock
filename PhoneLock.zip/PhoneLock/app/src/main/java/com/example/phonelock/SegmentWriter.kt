package com.example.phonelock

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Считает контрольные суммы готовых файлов в фоне и записывает их в журнал. */
object Hasher {
    private val ex = Executors.newSingleThreadExecutor { r ->
        Thread(r, "hasher").apply { priority = Thread.MIN_PRIORITY }
    }

    fun submit(block: () -> Unit) {
        ex.execute { block() }
    }

    fun awaitIdle(timeoutMs: Long) {
        try {
            ex.submit(Runnable { }).get(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        }
    }
}

/**
 * Пишет закодированное видео (и звук, если он подключён) в MP4-файлы в Movies/PhoneLock (MediaStore).
 * Если segmentMs > 0, начинает новый файл на первом ключевом кадре после этой длительности.
 * Видео не перекодируется и не монтируется. После закрытия файла в журнал пишется его SHA-256.
 */
class SegmentWriter(
    ctx: Context,
    private val sessionStamp: String,
    private val tag: String,
    private val segmentMs: Long
) {
    private val appCtx = ctx.applicationContext

    private var format: MediaFormat? = null
    private var audioFormat: MediaFormat? = null
    private var audioExpected = false
    private var waitStartNs = 0L

    private var muxer: Fmp4Muxer? = null
    private var stream: BufferedOutputStream? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var name = ""
    private var track = -1
    private var audioTrack = -1
    private var index = 0
    private var samples = 0
    private var segStartUs = 0L
    private var failed = false
    private var audioFailed = false
    private var suspended = false

    @Synchronized
    fun setFormat(f: MediaFormat) {
        format = f
    }

    /** Звук будет: ждём его формат перед началом файла. */
    @Synchronized
    fun expectAudio() {
        audioExpected = true
    }

    @Synchronized
    fun dropAudio() {
        audioExpected = false
    }

    @Synchronized
    fun setAudioFormat(f: MediaFormat) {
        audioFormat = f
    }

    /** Пауза: закрывает текущий файл и не начинает новый, пока не будет снята. */
    @Synchronized
    fun setSuspended(s: Boolean) {
        suspended = s
        if (s && muxer != null) finishSegment()
    }

    @Synchronized
    fun write(buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (failed || suspended) return
        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) return
        val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
        if (muxer != null && segmentMs > 0 && key && info.presentationTimeUs - segStartUs >= segmentMs * 1000) {
            finishSegment()
        }
        if (muxer == null) {
            if (!key) return
            if (audioExpected && audioFormat == null) {
                // звук ещё не готов: ждём до 3 секунд, потом пишем без звука
                if (waitStartNs == 0L) waitStartNs = System.nanoTime()
                if (System.nanoTime() - waitStartNs < 3_000_000_000L) return
                audioExpected = false
                RecLog.log("$tag: звук не успел подготовиться, файл начат без него")
            }
            if (!startSegment(info.presentationTimeUs)) return
        }
        val adj = MediaCodec.BufferInfo()
        adj.set(info.offset, info.size, info.presentationTimeUs - segStartUs, info.flags)
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        try {
            muxer!!.writeSample(track, buf, adj.presentationTimeUs, key)
            samples++
        } catch (e: Exception) {
            RecLog.log("$tag: ошибка записи файла: ${e.message}")
            failed = true
        }
    }

    @Synchronized
    fun writeAudio(buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (failed || audioFailed) return
        val m = muxer ?: return
        if (audioTrack < 0) return
        val rel = info.presentationTimeUs - segStartUs
        if (rel < 0) return
        val adj = MediaCodec.BufferInfo()
        adj.set(info.offset, info.size, rel, info.flags)
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        try {
            m.writeSample(audioTrack, buf, adj.presentationTimeUs, true)
        } catch (e: Exception) {
            RecLog.log("$tag: ошибка записи звука: ${e.message}")
            audioFailed = true
        }
    }

    @Synchronized
    fun close() {
        if (muxer != null) finishSegment()
    }

    private fun startSegment(ptsUs: Long): Boolean {
        val fmt = format
        if (fmt == null) {
            RecLog.log("$tag: нет формата видео")
            failed = true
            return false
        }
        var p: ParcelFileDescriptor? = null
        try {
            index++
            // Имя: камера и время начала именно этого файла, например PhoneLock_back_2026_11_12_17_01_05.mp4
            val ts = java.text.SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.US).format(java.util.Date())
            val n = "PhoneLock_${tag}_$ts.mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, n)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PhoneLock")
                put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
            }
            val u = appCtx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore не создал файл")
            uri = u
            p = appCtx.contentResolver.openFileDescriptor(u, "rw")
                ?: throw IllegalStateException("не удалось открыть файл")
            val fd = p.fileDescriptor
            val bs = BufferedOutputStream(FileOutputStream(fd), 256 * 1024)
            // Фрагментированный MP4: файл читается даже после внезапного выключения телефона
            val m = Fmp4Muxer(bs, onFlushed = { try { fd.sync() } catch (_: Exception) {} })
            val sps = nal(fmt, "csd-0")
            val pps = nal(fmt, "csd-1")
            track = m.addVideoTrack(sps, pps, fmt.getInteger(MediaFormat.KEY_WIDTH), fmt.getInteger(MediaFormat.KEY_HEIGHT))
            val af = audioFormat
            audioTrack = if (af != null && !audioFailed) {
                val b = af.getByteBuffer("csd-0") ?: throw IllegalStateException("нет параметров звука")
                val asc = ByteArray(b.remaining()).also { b.duplicate().get(it) }
                m.addAudioTrack(asc, af.getInteger(MediaFormat.KEY_SAMPLE_RATE), af.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
            } else -1
            m.start()
            muxer = m
            stream = bs
            pfd = p
            name = n
            segStartUs = ptsUs
            samples = 0
            RecLog.log("$tag: пишу файл $n" + if (audioTrack >= 0) " (со звуком)" else " (без звука)")
            return true
        } catch (e: Exception) {
            RecLog.log("$tag: не удалось начать файл: ${e.message}")
            try { p?.close() } catch (_: Exception) {}
            failed = true
            return false
        }
    }

    private fun finishSegment() {
        val u = uri
        val n = name
        try {
            muxer?.finish()
            stream?.flush()
            pfd?.fileDescriptor?.sync()
        } catch (e: Exception) {
            RecLog.log("$tag: завершение файла: ${e.message}")
        }
        try { stream?.close() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        if (samples == 0) {
            // пустой файл не оставляем
            try { u?.let { appCtx.contentResolver.delete(it, null, null) } } catch (_: Exception) {}
        } else {
            RecLog.log("$tag: файл $index сохранён")
            if (u != null) hashAsync(u, n)
        }
        muxer = null
        stream = null
        pfd = null
        uri = null
        track = -1
        audioTrack = -1
    }

    /** Параметры кодека (SPS/PPS) без стартовых кодов. */
    private fun nal(f: MediaFormat, key: String): ByteArray {
        val b = f.getByteBuffer(key) ?: throw IllegalStateException("нет $key")
        val raw = ByteArray(b.remaining()).also { b.duplicate().get(it) }
        return Fmp4Muxer.splitAnnexB(raw).firstOrNull() ?: throw IllegalStateException("пустой $key")
    }

    private fun hashAsync(u: Uri, n: String) {
        Hasher.submit {
            try {
                val md = MessageDigest.getInstance("SHA-256")
                var total = 0L
                appCtx.contentResolver.openInputStream(u)?.use { ins ->
                    val b = ByteArray(1 shl 20)
                    while (true) {
                        val r = ins.read(b)
                        if (r < 0) break
                        md.update(b, 0, r)
                        total += r
                    }
                }
                val hex = md.digest().joinToString("") { "%02x".format(it) }
                EventJournal.write("SHA-256 $n ($total байт): $hex")
            } catch (e: Exception) {
                EventJournal.write("SHA-256 $n: не удалось посчитать (${e.message})")
            }
        }
    }
}
