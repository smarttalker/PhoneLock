package com.example.phonelock

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Плитка в шторке уведомлений, честно подписанная «PhoneLock» — никакой маскировки под
 * другие системные переключатели. Нажатие отключает биометрию и начинает запись (экран блокируется кнопкой питания) —
 * быстрее, чем открывать приложение, при этом ничего не притворяется другой функцией.
 */
class LockTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile
        if (tile != null) {
            tile.label = getString(R.string.tile_label)
            tile.contentDescription = "Блокировка и экстренная запись"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
            tile.state = if (RecordingService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            tile.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        // Биометрия отключается и сразу идёт запись, но экран НЕ блокируем: человек сам нажимает
        // кнопку питания, после чего разблокировать можно только графическим ключом/PIN.
        //
        // Камеры + экран. Запускаем не напрямую, а через невидимую activity: из фона система запрещает стартовать
        // сервис с камерой и микрофоном, а из видимой activity — разрешает.
        val intent = Intent(this, StartRecordActivity::class.java)
            .putExtra(StartRecordActivity.EXTRA_FROM_TILE, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
        qsTile?.let {
            it.state = Tile.STATE_ACTIVE
            it.updateTile()
        }
    }
}
