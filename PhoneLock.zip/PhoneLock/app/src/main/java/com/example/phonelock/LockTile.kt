package com.example.phonelock

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Плитка в шторке уведомлений, честно подписанная «PhoneLock» — никакой маскировки под
 * другие системные переключатели. Нажатие отключает биометрию и начинает запись (экран блокируется кнопкой питания) —
 * быстрее, чем открывать приложение, при этом ничего не притворяется другой функцией.
 */
class LockTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile
        if (tile != null) {
            tile.label = "PhoneLock"
            tile.contentDescription = "Блокировка и экстренная запись"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_lock)
            tile.state = if (RecordingService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            tile.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        // Биометрия отключается и сразу идёт запись, но экран НЕ блокируем: человек сам нажимает
        // кнопку питания, после чего разблокировать можно только графическим ключом/PIN.
        val ok = LockAction.run(this, record = true, lockScreen = false)
        qsTile?.let {
            it.state = if (ok) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            it.updateTile()
        }
    }
}
