package com.example.phonelock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** После перезагрузки или обновления приложения: вернуть биометрию и запустить сервис. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        UnlockService.restoreBiometrics(context)
        try {
            val svc = Intent(context, UnlockService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc)
            else context.startService(svc)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}
