package com.example.phonelock

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Запись экрана: MediaProjection -> VirtualDisplay -> OpenGL (таймкод) -> MediaCodec (H.264) -> SegmentWriter (MP4).
 * Пока экран заблокирован, запись на паузе: файл закрывается, а после разблокировки начинается новый.
 * Кадры подаются с постоянной частотой 24 к/с, чтобы часы в углу шли даже на неподвижном экране.
 */
class ScreenPipeline(
    private val ctx: Context,
    private val projection: MediaProjection,
    segmentMs: Long,
    sessionStamp: String,
    private val onStopped: () -> Unit
) {
    val tag = "screen"
    val writer = SegmentWriter(ctx, sessionStamp, tag, segmentMs)

    private val outW: Int
    private val outH: Int
    private val dpi: Int

    private val glThread = HandlerThread("gl-screen").also { it.start() }
    private val glHandler = Handler(glThread.looper)
    private val encThread = HandlerThread("enc-screen").also { it.start() }
    private val encHandler = Handler(encThread.looper)

    @Volatile private var running = false
    @Volatile private var paused = false
    private val stopped = AtomicBoolean(false)
    private val eosLatch = CountDownLatch(1)
    private val newFrame = AtomicBoolean(false)

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var egl: EglCore? = null
    private var renderer: FrameRenderer? = null
    private var st: SurfaceTexture? = null
    private var vSurface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var have = false
    private var haveEver = false
    @Volatile private var resumedAtNs = 0L
    private val texMat = FloatArray(16)
    private var frameErrors = 0

    init {
        val dm = ctx.getSystemService(DisplayManager::class.java)
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getRealMetrics(m)
        // уменьшаем так, чтобы короткая сторона была 720, размеры чётные
        val scale = RecQuality.screenShort.toFloat() / minOf(m.widthPixels, m.heightPixels)
        outW = (m.widthPixels * scale).toInt() and 1.inv()
        outH = (m.heightPixels * scale).toInt() and 1.inv()
        dpi = m.densityDpi
    }

    fun start(startPaused: Boolean) {
        running = true
        paused = startPaused
        writer.setSuspended(startPaused)

        // С Android 14 обратный вызов нужно зарегистрировать до создания виртуального экрана
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopped.get()) {
                    RecLog.log("Запись экрана: остановлена системой или пользователем")
                    onStopped()
                }
            }
        }, Handler(Looper.getMainLooper()))

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, RecQuality.screenBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, RecQuality.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.setCallback(object : MediaCodec.Callback() {
            override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {}

            override fun onOutputBufferAvailable(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
                try {
                    val buf = codec.getOutputBuffer(index)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig) writer.write(buf, info)
                    codec.releaseOutputBuffer(index, false)
                } catch (e: Exception) {
                    RecLog.log("screen: ошибка вывода кодера: ${e.message}")
                }
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    writer.close()
                    eosLatch.countDown()
                }
            }

            override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
                RecLog.log("screen: ошибка кодера: ${e.message}")
            }

            override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
                writer.setFormat(format)
            }
        }, encHandler)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = enc.createInputSurface()
        enc.start()
        encoder = enc
        glHandler.post { initGl() }
    }

    private fun initGl() {
        try {
            val e = EglCore(inputSurface!!)
            e.makeCurrent()
            egl = e
            val r = FrameRenderer(outW, outH, outW, outH, 0)
            renderer = r
            val s = SurfaceTexture(r.oesTex)
            s.setDefaultBufferSize(outW, outH)
            s.setOnFrameAvailableListener({ newFrame.set(true) }, glHandler)
            st = s
            val surf = Surface(s)
            vSurface = surf
            vd = projection.createVirtualDisplay(
                "PhoneLock-screen", outW, outH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                if (paused) null else surf, null, null
            )
            RecLog.log("Запись экрана: ${outW}x$outH" + if (paused) ", экран сейчас заблокирован, жду разблокировки" else ", идёт")
            glHandler.post(tick)
        } catch (e: Exception) {
            RecLog.log("Запись экрана: не запустилась: ${e.message}")
            onStopped()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                if (!paused) {
                    val s = st
                    val r = renderer
                    val e = egl
                    if (s != null && r != null && e != null) {
                        if (newFrame.getAndSet(false)) {
                            s.updateTexImage()
                            s.getTransformMatrix(texMat)
                            have = true
                            haveEver = true
                        }
                        // Экран не меняется и новых кадров нет: через 0,7 с рисуем последний, чтобы файл начался
                        if (!have && haveEver && SystemClock.elapsedRealtime() * 1_000_000L - resumedAtNs > 700_000_000L) have = true
                        if (have) {
                            r.draw(texMat)
                            e.setPresentationTime(SystemClock.elapsedRealtimeNanos())
                            e.swap()
                        }
                    }
                }
            } catch (ex: Exception) {
                if (frameErrors++ < 3) RecLog.log("screen: ошибка кадра: ${ex.message}")
            }
            glHandler.postDelayed(this, 1000L / RecQuality.fps)
        }
    }

    /** Экран заблокирован: закрываем файл и перестаём снимать. */
    fun pause() {
        glHandler.post {
            if (paused || !running) return@post
            paused = true
            writer.setSuspended(true)
            try { vd?.surface = null } catch (_: Exception) {}
            RecLog.log("Запись экрана: пауза (экран заблокирован)")
        }
    }

    /** Экран разблокирован: начинаем новый файл. */
    fun resume() {
        glHandler.post {
            if (!paused || !running) return@post
            paused = false
            have = false
            newFrame.set(false)
            resumedAtNs = SystemClock.elapsedRealtime() * 1_000_000L
            try { vd?.surface = vSurface } catch (_: Exception) {}
            try {
                encoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
            } catch (_: Exception) {
            }
            writer.setSuspended(false)
            RecLog.log("Запись экрана: возобновлена")
        }
    }

    fun stopBlocking() {
        if (!stopped.compareAndSet(false, true)) return
        running = false
        val done = CountDownLatch(1)
        glHandler.post {
            glHandler.removeCallbacks(tick)
            try { encoder?.signalEndOfInputStream() } catch (e: Exception) {
                RecLog.log("screen: конец потока: ${e.message}")
            }
            try { vd?.release() } catch (_: Exception) {}
            try { projection.stop() } catch (_: Exception) {}
            try { st?.setOnFrameAvailableListener(null) } catch (_: Exception) {}
            try { st?.release() } catch (_: Exception) {}
            try { vSurface?.release() } catch (_: Exception) {}
            try { renderer?.release() } catch (_: Exception) {}
            try { egl?.release() } catch (_: Exception) {}
            vd = null
            st = null
            vSurface = null
            renderer = null
            egl = null
            done.countDown()
        }
        done.await(3, TimeUnit.SECONDS)
        if (!eosLatch.await(4, TimeUnit.SECONDS)) {
            RecLog.log("screen: кодер не завершился вовремя, закрываю файл принудительно")
            writer.close()
        }
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        try { inputSurface?.release() } catch (_: Exception) {}
        glThread.quitSafely()
        encThread.quitSafely()
        RecLog.log("screen: остановлено")
    }

    companion object {
    }
}
