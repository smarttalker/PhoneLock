package com.example.phonelock

import android.content.Context

/** Параметры качества записи. Загружаются из настроек при старте записи. */
object RecQuality {
    class Preset(val id: String, val title: String, val fps: Int, val camW: Int, val camBitrate: Int, val screenShort: Int, val screenBitrate: Int)

    val PRESETS = listOf(
        Preset("min", "Минимальное", 15, 640, 1_000_000, 480, 800_000),
        Preset("light", "Лёгкое", 24, 960, 2_000_000, 540, 1_500_000),
        Preset("normal", "Обычное", 24, 1280, 5_000_000, 720, 3_000_000),
    )

    @Volatile var fps = 24
    @Volatile var camW = 960
    @Volatile var camBitrate = 2_000_000
    @Volatile var screenShort = 540
    @Volatile var screenBitrate = 1_500_000

    fun load(ctx: Context) {
        val p = PRESETS.firstOrNull { it.id == Prefs.quality(ctx) } ?: PRESETS[1]
        fps = p.fps; camW = p.camW; camBitrate = p.camBitrate
        screenShort = p.screenShort; screenBitrate = p.screenBitrate
    }
}
