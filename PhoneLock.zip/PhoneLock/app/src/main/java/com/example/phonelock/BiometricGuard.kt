package com.example.phonelock

import android.app.KeyguardManager
import android.app.admin.DeviceAdminInfo
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/**
 * Отключение отпечатка/лица/Smart Lock на экране блокировки через права администратора.
 * Работает, только если администратору выдана политика «disable-keyguard-features» —
 * она добавлена в device_admin.xml, но применяется лишь после ПЕРЕВЫДАЧИ прав администратора.
 */
object BiometricGuard {
    const val FLAGS = DevicePolicyManager.KEYGUARD_DISABLE_FINGERPRINT or
        DevicePolicyManager.KEYGUARD_DISABLE_FACE or
        DevicePolicyManager.KEYGUARD_DISABLE_IRIS or
        DevicePolicyManager.KEYGUARD_DISABLE_TRUST_AGENTS

    private fun admin(ctx: Context) = ComponentName(ctx, AdminReceiver::class.java)

    fun adminActive(ctx: Context): Boolean =
        ctx.getSystemService(DevicePolicyManager::class.java).isAdminActive(admin(ctx))

    fun policyGranted(ctx: Context): Boolean = try {
        ctx.getSystemService(DevicePolicyManager::class.java)
            .hasGrantedPolicy(admin(ctx), DeviceAdminInfo.USES_POLICY_DISABLE_KEYGUARD_FEATURES)
    } catch (_: Throwable) {
        false
    }

    /** Отключает биометрию и возвращает отчёт: что применилось и что система реально запомнила. */
    fun disable(ctx: Context): String {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val a = admin(ctx)
        if (!dpm.isAdminActive(a)) return "Права администратора не выданы"
        val secure = ctx.getSystemService(KeyguardManager::class.java).isDeviceSecure
        val granted = policyGranted(ctx)
        val sb = StringBuilder()
        sb.append("политика отключения биометрии: ").append(if (granted) "выдана" else "НЕ выдана").append("; ")
        sb.append("экран защищён ключом/PIN: ").append(if (secure) "да" else "НЕТ (биометрия не используется)").append("; ")
        try {
            dpm.setKeyguardDisabledFeatures(a, FLAGS)
            val now = dpm.getKeyguardDisabledFeatures(a)
            val ok = (now and FLAGS) == FLAGS
            sb.append("флаги записаны=0x").append(Integer.toHexString(FLAGS))
                .append(", система хранит=0x").append(Integer.toHexString(now))
                .append(if (ok) " — ОК" else " — НЕ СОВПАЛО")
        } catch (e: Throwable) {
            sb.append("ошибка: ").append(e.javaClass.simpleName).append(": ").append(e.message)
            if (!granted) sb.append(" → переоформи права администратора")
        }
        return sb.toString()
    }

    fun restore(ctx: Context) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val a = admin(ctx)
        if (dpm.isAdminActive(a)) {
            try {
                dpm.setKeyguardDisabledFeatures(a, DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_NONE)
            } catch (_: Throwable) {
            }
        }
    }
}
