package com.example.phonelock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Невидимая activity: запускается иконкой приложения или ярлыком «Блокировка». */
class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LockAction.run(this, record = Prefs.lockAlsoRecords(this))) {
            // Прав администратора нет — заблокировать экран не вышло. Вместо того чтобы
            // молча открыть обычный экран приложения (выглядит как «завис экран»), сразу
            // объясняем причину и просим выдать права.
            Toast.makeText(this, "Нет прав администратора — блокировка не сработала", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).putExtra("need_admin", true))
        }
        finish()
    }
}
