package com.example.phonelock

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Невидимая activity: запускается иконкой приложения или ярлыком «Блокировка». */
class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LockAction.run(this)) {
            startActivity(Intent(this, MainActivity::class.java).putExtra("settings", true))
        }
        finish()
    }
}
