package com.example.phonelock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat

/**
 * Следит за извлечением SIM-карты (сигнал активного вмешательства в телефон, а не
 * просто «кто-то взял его в руки»). Регистрируется и снимается вместе с UnlockService,
 * пока он работает как foreground-сервис — отдельного постоянного процесса не заводит.
 */
object SimWatcher {
    private var receiver: BroadcastReceiver? = null

    fun register(context: Context) {
        if (receiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                // "ss" — состояние SIM, Android кладёт его в этот broadcast с первых версий
                // системы ("ABSENT", "READY", "LOCKED", ...); официальной константы для него
                // в публичном SDK нет, но extra стабилен и им пользуются сторонние антивор-приложения.
                if (intent.getStringExtra("ss") == "ABSENT") onSimRemoved(ctx)
            }
        }
        val filter = IntentFilter("android.intent.action.SIM_STATE_CHANGED")
        try {
            ContextCompat.registerReceiver(context, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiver = r
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    fun unregister(context: Context) {
        try {
            receiver?.let { context.unregisterReceiver(it) }
        } catch (_: Throwable) {
        }
        receiver = null
    }

    private fun onSimRemoved(context: Context) {
        val action = Prefs.simRemovedAction(context)
        if (action == "off") return
        Prefs.setLastAction(context, "SIM-карта извлечена → $action")
        LockAction.run(context, startService = false)
        if (CameraCapture.hasPermission(context)) CameraCapture.capture(context)
        if (action == "record") {
            try {
                RecordingService.start(context, 0, bothCameras = true)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }
}
