package com.example.phonelock

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** EGL-контекст, рисующий прямо в входную поверхность видеокодера. */
class EglCore(encoderSurface: Surface) {
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var surface: EGLSurface = EGL14.EGL_NO_SURFACE

    init {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "нет EGL display" }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "eglInitialize" }
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "eglChooseConfig" }
        context = EGL14.eglCreateContext(
            display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        check(context != EGL14.EGL_NO_CONTEXT) { "eglCreateContext" }
        surface = EGL14.eglCreateWindowSurface(display, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        check(surface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface" }
    }

    fun makeCurrent() {
        EGL14.eglMakeCurrent(display, surface, surface, context)
    }

    fun setPresentationTime(ns: Long) {
        EGLExt.eglPresentationTimeANDROID(display, surface, ns)
    }

    fun swap(): Boolean = EGL14.eglSwapBuffers(display, surface)

    fun release() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface)
            if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(display)
        }
        display = EGL14.EGL_NO_DISPLAY
        context = EGL14.EGL_NO_CONTEXT
        surface = EGL14.EGL_NO_SURFACE
    }

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142
    }
}

private fun floatBuf(a: FloatArray): FloatBuffer =
    ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(a)
        position(0)
    }

private fun compileShader(type: Int, src: String): Int {
    val s = GLES20.glCreateShader(type)
    GLES20.glShaderSource(s, src)
    GLES20.glCompileShader(s)
    val ok = IntArray(1)
    GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
    check(ok[0] != 0) { "shader: " + GLES20.glGetShaderInfoLog(s) }
    return s
}

private fun buildProgram(vs: String, fs: String): Int {
    val p = GLES20.glCreateProgram()
    GLES20.glAttachShader(p, compileShader(GLES20.GL_VERTEX_SHADER, vs))
    GLES20.glAttachShader(p, compileShader(GLES20.GL_FRAGMENT_SHADER, fs))
    GLES20.glLinkProgram(p)
    val ok = IntArray(1)
    GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
    check(ok[0] != 0) { "link: " + GLES20.glGetProgramInfoLog(p) }
    return p
}

/**
 * Рисует кадр камеры с поворотом и накладывает дату/время (с секундами).
 * Кадр камеры приходит в ориентации сенсора, поэтому поворачиваем его на rotationCw градусов по часовой.
 */
class FrameRenderer(
    private val srcW: Int,
    private val srcH: Int,
    private val outW: Int,
    private val outH: Int,
    private val rotationCw: Int
) {
    val oesTex: Int
    private val overlayTex: Int
    private val oesProg: Int
    private val prog2d: Int

    private val aPosOes: Int
    private val aTcOes: Int
    private val uMvpOes: Int
    private val uTexOes: Int
    private val uSamplerOes: Int

    private val aPos2d: Int
    private val aTc2d: Int
    private val uMvp2d: Int
    private val uSampler2d: Int

    private val quadPos = floatBuf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val quadTc = floatBuf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
    private val ovPos = floatBuf(FloatArray(8))
    private val ovTc = floatBuf(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))

    private val proj = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    private val overlay = TimeOverlay(minOf(outW, outH))

    init {
        val t = IntArray(2)
        GLES20.glGenTextures(2, t, 0)
        oesTex = t[0]
        overlayTex = t[1]

        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        setTexParams(GLES11Ext.GL_TEXTURE_EXTERNAL_OES)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        setTexParams(GLES20.GL_TEXTURE_2D)

        oesProg = buildProgram(
            """
            uniform mat4 uMvp;
            uniform mat4 uTex;
            attribute vec4 aPos;
            attribute vec4 aTc;
            varying vec2 vTc;
            void main() {
                gl_Position = uMvp * aPos;
                vTc = (uTex * aTc).xy;
            }
            """.trimIndent(),
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTc;
            uniform samplerExternalOES sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
            """.trimIndent()
        )
        prog2d = buildProgram(
            """
            uniform mat4 uMvp;
            attribute vec4 aPos;
            attribute vec2 aTc;
            varying vec2 vTc;
            void main() {
                gl_Position = uMvp * aPos;
                vTc = aTc;
            }
            """.trimIndent(),
            """
            precision mediump float;
            varying vec2 vTc;
            uniform sampler2D sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
            """.trimIndent()
        )

        aPosOes = GLES20.glGetAttribLocation(oesProg, "aPos")
        aTcOes = GLES20.glGetAttribLocation(oesProg, "aTc")
        uMvpOes = GLES20.glGetUniformLocation(oesProg, "uMvp")
        uTexOes = GLES20.glGetUniformLocation(oesProg, "uTex")
        uSamplerOes = GLES20.glGetUniformLocation(oesProg, "sTex")

        aPos2d = GLES20.glGetAttribLocation(prog2d, "aPos")
        aTc2d = GLES20.glGetAttribLocation(prog2d, "aTc")
        uMvp2d = GLES20.glGetUniformLocation(prog2d, "uMvp")
        uSampler2d = GLES20.glGetUniformLocation(prog2d, "sTex")
    }

    private fun setTexParams(target: Int) {
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    fun draw(texMatrix: FloatArray) {
        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        // Поворот камеры: прямоугольник размером с буфер камеры, повёрнутый на rotationCw по часовой
        Matrix.orthoM(proj, 0, -outW / 2f, outW / 2f, -outH / 2f, outH / 2f, -1f, 1f)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, -rotationCw.toFloat(), 0f, 0f, 1f)
        Matrix.scaleM(model, 0, srcW / 2f, srcH / 2f, 1f)
        Matrix.multiplyMM(mvp, 0, proj, 0, model, 0)

        GLES20.glUseProgram(oesProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glUniform1i(uSamplerOes, 0)
        GLES20.glUniformMatrix4fv(uMvpOes, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uTexOes, 1, false, texMatrix, 0)
        GLES20.glEnableVertexAttribArray(aPosOes)
        GLES20.glVertexAttribPointer(aPosOes, 2, GLES20.GL_FLOAT, false, 8, quadPos)
        GLES20.glEnableVertexAttribArray(aTcOes)
        GLES20.glVertexAttribPointer(aTcOes, 2, GLES20.GL_FLOAT, false, 8, quadTc)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPosOes)
        GLES20.glDisableVertexAttribArray(aTcOes)

        drawOverlay()
    }

    private fun drawOverlay() {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        overlay.update()

        val margin = minOf(outW, outH) * 0.02f
        val w = overlay.width.toFloat()
        val h = overlay.height.toFloat()
        val x0 = margin
        val x1 = margin + w
        val y1 = outH - margin
        val y0 = y1 - h
        ovPos.position(0)
        ovPos.put(floatArrayOf(x0, y0, x1, y0, x0, y1, x1, y1))
        ovPos.position(0)

        Matrix.orthoM(proj, 0, 0f, outW.toFloat(), 0f, outH.toFloat(), -1f, 1f)

        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(prog2d)
        GLES20.glUniform1i(uSampler2d, 0)
        GLES20.glUniformMatrix4fv(uMvp2d, 1, false, proj, 0)
        GLES20.glEnableVertexAttribArray(aPos2d)
        GLES20.glVertexAttribPointer(aPos2d, 2, GLES20.GL_FLOAT, false, 8, ovPos)
        GLES20.glEnableVertexAttribArray(aTc2d)
        GLES20.glVertexAttribPointer(aTc2d, 2, GLES20.GL_FLOAT, false, 8, ovTc)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos2d)
        GLES20.glDisableVertexAttribArray(aTc2d)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    fun release() {
        overlay.release()
    }
}

/** Плашка с датой и временем «гггг-мм-дд чч:мм:сс» в левом верхнем углу, обновляется раз в секунду. */
class TimeOverlay(shortSide: Int) {
    private val textPx = shortSide * 0.045f
    private val pad = textPx * 0.35f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = textPx
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = Color.WHITE
        setShadowLayer(textPx * 0.08f, 0f, 0f, Color.BLACK)
    }
    private val bgPaint = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val fm = paint.fontMetrics
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    val width: Int = (paint.measureText("0000-00-00 00:00:00") + pad * 2).toInt()
    val height: Int = (fm.descent - fm.ascent + pad * 2).toInt()

    private val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(bmp)
    private var lastSec = -1L

    /** Вызывать при привязанной текстуре GL_TEXTURE_2D. */
    fun update() {
        val now = System.currentTimeMillis()
        val sec = now / 1000
        if (sec == lastSec) return
        lastSec = sec
        bmp.eraseColor(Color.TRANSPARENT)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        canvas.drawText(fmt.format(Date(now)), pad, pad - fm.ascent, paint)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    fun release() {
        bmp.recycle()
    }
}
