package com.example.phonelock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock

/**
 * 1) Ждёт ACTION_USER_PRESENT (телефон разблокирован) и возвращает отпечаток/лицо.
 * 2) Если включено в настройках — следит за акселерометром (только пока экран включён)
 *    и блокирует телефон при резком рывке.
 */
class UnlockService : Service(), SensorEventListener {

    private var sensorManager: SensorManager? = null
    private var listening = false
    private var thresholdG = 3.25f
    private var lastTrigger = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_USER_PRESENT -> restoreBiometrics(context)
                Intent.ACTION_SCREEN_ON -> {
                    updateShake()
                    if (Prefs.photoOnScreenOn(context) && CameraCapture.hasPermission(context)) {
                        CameraCapture.capture(context)
                    }
                }
                Intent.ACTION_SCREEN_OFF -> updateShake()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Название канала и текст уведомления сделаны нейтральными специально:
        // если телефон украли, незачем подсказывать вору, что он под наблюдением.
        // Убрать уведомление совсем нельзя — без него Android выключит саму
        // службу, и рывок/фото/возврат биометрии перестанут работать.
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Системная служба", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Синхронизация")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }

        val filter = IntentFilter()
        filter.addAction(Intent.ACTION_USER_PRESENT)
        filter.addAction(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        registerReceiver(receiver, filter)
        SimWatcher.register(this)
        updateShake()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        updateShake()
        return START_STICKY
    }

    override fun onDestroy() {
        if (listening) {
            sensorManager?.unregisterListener(this)
            listening = false
        }
        unregisterReceiver(receiver)
        SimWatcher.unregister(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Включает или выключает слежение за рывком по настройкам и состоянию экрана. */
    private fun updateShake() {
        val enabled = Prefs.shakeEnabled(this)
        val level = Prefs.shakeSensitivity(this)
        thresholdG = 5.0f - 0.35f * level

        val pm = getSystemService(PowerManager::class.java)
        val interactive = pm?.isInteractive ?: true
        val want = enabled && interactive

        var manager = sensorManager
        if (manager == null) {
            manager = getSystemService(SensorManager::class.java)
            sensorManager = manager
        }
        if (manager == null) return

        if (want && !listening) {
            val sensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (sensor != null) {
                manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
                listening = true
            }
        } else if (!want && listening) {
            manager.unregisterListener(this)
            listening = false
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val g = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat() / SensorManager.GRAVITY_EARTH
        if (g < thresholdG) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < 3000) return
        lastTrigger = now
        LockAction.run(this, false)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        private const val CHANNEL = "phonelock"

        fun restoreBiometrics(context: Context) {
            val dpm = context.getSystemService(DevicePolicyManager::class.java)
            val admin = ComponentName(context, AdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) {
                try {
                    dpm.setKeyguardDisabledFeatures(
                        admin, DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_NONE
                    )
                } catch (e: SecurityException) {
                    e.printStackTrace()
                }
            }
        }
    }
}
