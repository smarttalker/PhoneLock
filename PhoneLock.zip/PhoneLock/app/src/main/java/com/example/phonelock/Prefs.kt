package com.example.phonelock

import android.content.Context

/**
 * Все настройки приложения в одном месте. Один файл SharedPreferences "phonelock".
 *
 * Два отдельных PIN-кода защищают настройки:
 *  - обычный PIN — им вы сами открываете чувствительные настройки (выключить защиту,
 *    посмотреть/удалить записи);
 *  - дополнительный PIN «под принуждением» — если вас заставляют открыть настройки и
 *    что-то показать/выключить, вы вводите его вместо настоящего. Экран ведёт себя как
 *    обычно (настоящую защиту вы НЕ отключаете), но в фоне тихо запускается запись.
 *    Это стандартный приём «duress code» — вы один знаете, что он означает.
 */
object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("phonelock", Context.MODE_PRIVATE)

    // ---------- Блокировка / рывок ----------

    fun shakeEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("shake", false)
    fun setShakeEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("shake", v).apply()

    fun shakeSensitivity(ctx: Context): Int = sp(ctx).getInt("sens", 5)
    fun setShakeSensitivity(ctx: Context, v: Int) = sp(ctx).edit().putInt("sens", v).apply()

    // ---------- Фото при разблокировке (честно: при КАЖДОМ включении экрана,
    // Android не даёт узнать именно о вводе верного ключа отдельно) ----------

    fun photoOnScreenOn(ctx: Context): Boolean = sp(ctx).getBoolean("photo_on_unlock", false)
    fun setPhotoOnScreenOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("photo_on_unlock", v).apply()

    fun photoCount(ctx: Context): Int = sp(ctx).getInt("photo_count", 0)
    fun photoLast(ctx: Context): String? = sp(ctx).getString("photo_last", null)
    fun noteCapturedPhoto(ctx: Context, whenText: String) {
        sp(ctx).edit()
            .putInt("photo_count", photoCount(ctx) + 1)
            .putString("photo_last", whenText)
            .apply()
    }

    // ---------- Неверный код на системном экране блокировки (DeviceAdminReceiver.onPasswordFailed) ----------

    /** Делать фото сразу при каждой неверной попытке ввода кода/рисунка/биометрии. */
    fun photoOnWrongPassword(ctx: Context): Boolean = sp(ctx).getBoolean("photo_wrong_pwd", true)
    fun setPhotoOnWrongPassword(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("photo_wrong_pwd", v).apply()

    /** После скольких подряд неверных попыток включать полную запись (камеры+звук). 0 — никогда. */
    fun recordAfterWrongAttempts(ctx: Context): Int = sp(ctx).getInt("record_after_attempts", 3)
    fun setRecordAfterWrongAttempts(ctx: Context, v: Int) = sp(ctx).edit().putInt("record_after_attempts", v).apply()

    fun wrongAttemptStreak(ctx: Context): Int = sp(ctx).getInt("wrong_streak", 0)
    fun setWrongAttemptStreak(ctx: Context, v: Int) = sp(ctx).edit().putInt("wrong_streak", v).apply()

    // ---------- Извлечение SIM-карты ----------

    /** "off" | "photo" | "record" (фото и/или запись + немедленная блокировка). */
    fun simRemovedAction(ctx: Context): String = sp(ctx).getString("sim_action", "photo") ?: "photo"
    fun setSimRemovedAction(ctx: Context, v: String) = sp(ctx).edit().putString("sim_action", v).apply()

    // ---------- Какое приложение открыть после блокировки (необязательно) ----------

    fun launchPkg(ctx: Context): String? = sp(ctx).getString("launch_pkg", null)
    fun setLaunchPkg(ctx: Context, v: String?) = sp(ctx).edit().apply {
        if (v == null) remove("launch_pkg") else putString("launch_pkg", v)
    }.apply()

    fun launchComponent(ctx: Context): String? = sp(ctx).getString("launch_component", null)
    fun setLaunchComponent(ctx: Context, v: String?) = sp(ctx).edit().apply {
        if (v == null) remove("launch_component") else putString("launch_component", v)
        remove("launch_pkg")
    }.apply()

    // ---------- Диагностика ----------

    fun lastAction(ctx: Context): String? = sp(ctx).getString("last", null)
    fun setLastAction(ctx: Context, v: String) = sp(ctx).edit().putString("last", v).apply()

    fun lastLaunch(ctx: Context): String? = sp(ctx).getString("launch_diag", null)
    fun setLastLaunch(ctx: Context, v: String) = sp(ctx).edit().putString("launch_diag", v).apply()

    // ---------- Запись (бывшие настройки EvidenceCam) ----------

    /** Длина одного файла в минутах. 0 = не разбивать. */
    fun segmentMinutes(ctx: Context): Int = sp(ctx).getInt("segment_min", 5)
    fun setSegmentMinutes(ctx: Context, minutes: Int) = sp(ctx).edit().putInt("segment_min", minutes).apply()

    /** "back" - основная, "front" - фронтальная, "both" - обе (если телефон позволяет). */
    fun cameraChoice(ctx: Context): String = sp(ctx).getString("camera", "back") ?: "back"
    fun setCameraChoice(ctx: Context, v: String) = sp(ctx).edit().putString("camera", v).apply()

    /** В видео какой камеры писать звук: "both" - в оба, "back" - только в основную, "front" - только во фронтальную. */
    fun audioCamera(ctx: Context): String = sp(ctx).getString("audio_camera", "both") ?: "both"
    fun setAudioCamera(ctx: Context, v: String) = sp(ctx).edit().putString("audio_camera", v).apply()

    fun audioEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("audio", true)
    fun setAudioEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("audio", v).apply()

    /** Индекс в AudioPipeline.SOURCES. */
    fun audioSource(ctx: Context): Int = sp(ctx).getInt("audio_source", 0)
    fun setAudioSource(ctx: Context, v: Int) = sp(ctx).edit().putInt("audio_source", v).apply()

    /** Записывать ли экран при обычном (не панич-) старте записи. Система спросит подтверждение. */
    fun screenRecording(ctx: Context): Boolean = sp(ctx).getBoolean("screen", true)
    fun setScreenRecording(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("screen", v).apply()

    /**
     * Что делать после разблокировки, если систему оборвала запись экрана:
     * "off" - ничего, "notify" - маленькое уведомление (по умолчанию), "window" - сразу большое окно подтверждения.
     */
    fun screenPrompt(ctx: Context): String = sp(ctx).getString("screen_prompt", "notify") ?: "notify"
    fun setScreenPrompt(ctx: Context, v: String) = sp(ctx).edit().putString("screen_prompt", v).apply()

    /** Начинать запись сразу при открытии приложения. */
    fun autoStart(ctx: Context): Boolean = sp(ctx).getBoolean("autostart", false)
    fun setAutoStart(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("autostart", v).apply()

    // ---------- PIN-коды настроек (обычный и «под принуждением») ----------

    private fun salted(salt: String, pin: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun newSalt(): String =
        ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

    fun hasPin(ctx: Context): Boolean = sp(ctx).contains("pin_hash")
    fun setPin(ctx: Context, pin: String) {
        val salt = newSalt()
        sp(ctx).edit().putString("pin_salt", salt).putString("pin_hash", salted(salt, pin)).apply()
    }
    fun checkPin(ctx: Context, pin: String): Boolean {
        val salt = sp(ctx).getString("pin_salt", null) ?: return false
        return salted(salt, pin) == sp(ctx).getString("pin_hash", null)
    }

    fun hasDuressPin(ctx: Context): Boolean = sp(ctx).contains("duress_hash")
    fun setDuressPin(ctx: Context, pin: String) {
        val salt = newSalt()
        sp(ctx).edit().putString("duress_salt", salt).putString("duress_hash", salted(salt, pin)).apply()
    }
    fun checkDuressPin(ctx: Context, pin: String): Boolean {
        val salt = sp(ctx).getString("duress_salt", null) ?: return false
        return salted(salt, pin) == sp(ctx).getString("duress_hash", null)
    }
    fun clearDuressPin(ctx: Context) = sp(ctx).edit().remove("duress_hash").remove("duress_salt").apply()
}
