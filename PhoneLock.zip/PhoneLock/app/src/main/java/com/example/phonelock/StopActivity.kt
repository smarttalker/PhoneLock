package com.example.phonelock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme

/**
 * Пункт «Остановить» в меню долгого нажатия на иконку. Если в приложении задан PIN —
 * останавливает запись только после его ввода, иначе (PIN не задан) останавливает сразу.
 */
class StopActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Prefs.hasPin(this)) {
            RecordingService.stop(this)
            finish()
            return
        }
        setContent {
            MaterialTheme {
                PinAskDialog(
                    onDismiss = { finish() },
                    onOk = {
                        RecordingService.stop(this@StopActivity)
                        finish()
                    }
                )
            }
        }
    }
}
