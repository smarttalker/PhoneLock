package com.example.phonelock

import android.app.Activity
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Surface
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Невидимая activity для виджета «Запись»: начинает писать с камер (по настройке «Камера»
 * в разделе «Настройки записи») И с экрана — экран при этом НЕ блокирует и НЕ выключает,
 * в отличие от «Экстренной записи». Запись экрана по-прежнему требует обязательного
 * системного окна подтверждения — Android не даёт получить его в обход.
 */
class StartRecordActivity : ComponentActivity() {
    companion object {
        const val EXTRA_FROM_TILE = "from_tile"
    }

    private val screenLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            RecordingService.attachScreen(this, r.resultCode, data)
        } else {
            RecLog.log("Запись экрана: разрешение не дано, продолжаю только с камерами")
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rotation = (display?.rotation ?: Surface.ROTATION_0) * 90
        // Запуск с плитки: отключаем биометрию (экран не блокируем) и пишем обе камеры + экран.
        val fromTile = intent?.getBooleanExtra(EXTRA_FROM_TILE, false) == true
        if (fromTile) LockAction.run(this, record = false, lockScreen = false)
        RecordingService.start(this, rotation, bothCameras = fromTile)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        screenLauncher.launch(intent)
    }
}
