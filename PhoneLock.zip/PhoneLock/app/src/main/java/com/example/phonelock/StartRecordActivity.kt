package com.example.phonelock

import android.app.Activity
import android.os.Bundle
import android.view.Surface

/**
 * Невидимая activity для виджета «Запись»: только начинает писать с камер (по настройке
 * «Камера» в разделе «Настройки записи») — экран НЕ блокирует и НЕ выключает, в отличие
 * от виджета «Паника».
 */
class StartRecordActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rotation = ((display?.rotation ?: Surface.ROTATION_0) * 90)
        RecordingService.start(this, rotation)
        finish()
    }
}
