package com.example.phonelock

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Отдельный журнал GPS и ADB: показывается на вкладке «GPS и ADB», чтобы было видно, что работает, а что нет. */
object GpsLog {
    var lines by mutableStateOf<List<String>>(emptyList())
        private set

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun clear() {
        lines = emptyList()
    }

    @Synchronized
    fun log(msg: String) {
        Log.i("PhoneLockGps", msg)
        lines = (lines + "${fmt.format(Date())} $msg").takeLast(300)
    }
}
