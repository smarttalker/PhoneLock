package com.example.phonelock

import android.content.ContentValues
import android.content.Context
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Текстовый журнал сессии: Documents/PhoneLock/PhoneLock_<время>_journal.txt.
 * Каждая строка сразу сбрасывается на диск. Сюда попадают старт и остановка, звонки,
 * состояние экрана, ошибки камер, периоды тишины в микрофоне и контрольные суммы файлов.
 */
object EventJournal {
    private var pfd: ParcelFileDescriptor? = null
    private var out: OutputStream? = null
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun open(ctx: Context, stamp: String) {
        close()
        try {
            val values = ContentValues().apply {
                put(MediaStore.Files.FileColumns.DISPLAY_NAME, "PhoneLock_${stamp}_journal.txt")
                put(MediaStore.Files.FileColumns.MIME_TYPE, "text/plain")
                put(MediaStore.Files.FileColumns.RELATIVE_PATH, "Documents/PhoneLock")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
            if (uri == null) {
                Log.w("PhoneLock", "журнал: MediaStore не создал файл")
                return
            }
            val p = ctx.contentResolver.openFileDescriptor(uri, "w")
            if (p == null) {
                Log.w("PhoneLock", "журнал: не удалось открыть файл")
                return
            }
            pfd = p
            out = ParcelFileDescriptor.AutoCloseOutputStream(p)
        } catch (e: Exception) {
            Log.w("PhoneLock", "журнал: ${e.message}")
        }
    }

    @Synchronized
    fun write(msg: String) {
        val o = out ?: return
        try {
            o.write("[${fmt.format(Date())}] $msg\n".toByteArray(Charsets.UTF_8))
            o.flush()
            pfd?.fileDescriptor?.sync()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun close() {
        try { out?.close() } catch (_: Exception) {}
        out = null
        pfd = null
    }
}
