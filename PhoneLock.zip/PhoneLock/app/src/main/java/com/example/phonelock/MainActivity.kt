package com.example.phonelock

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Surface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.activity.ComponentActivity
import kotlinx.coroutines.delay

// ДОБАВЛЕННЫЕ ИМПОРТЫ ДЛЯ ADB
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

/**
 * Единственный экран приложения (кроме мгновенной блокировки через LockActivity/плитку/виджет).
 * Если задан PIN — сначала экран-засов (PinGate): настоящий PIN открывает обычный экран,
 * PIN «под принуждением» тоже открывает обычный экран (чтобы не выдать, что он особый), но
 * вдобавок тихо запускает запись. Неверный PIN просто не пускает дальше.
 */
class MainActivity : ComponentActivity() {

    private var freshLaunch = true

    private fun isAdmin(): Boolean {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun batteryFree(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun tryStart(vararg intents: Intent) {
        for (i in intents) {
            try {
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {
            }
        }
        Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
    }

    private fun overlayOk(): Boolean = Settings.canDrawOverlays(this)
    private fun askOverlay() = tryStart(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
        appDetails()
    )
    private fun appDetails() = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    private fun askBatteryFree() = tryStart(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    )
    private fun openAutostart() = tryStart(
        Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
        Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT),
        appDetails()
    )
    private fun openPowerSettings() = tryStart(
        Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY")
            .setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
            .putExtra("package_name", packageName)
            .putExtra("package_label", getString(R.string.app_name)),
        appDetails()
    )

    private fun requestAdmin() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this@MainActivity, AdminReceiver::class.java))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Нужно, чтобы мгновенно блокировать экран и видеть неверные попытки ввода кода."
            )
        }
        startActivity(intent)
    }

    private fun startUnlockService() {
        try {
            val svc = Intent(this, UnlockService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun screenIntent(): Intent {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        return if (Build.VERSION.SDK_INT >= 34) {
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
    }

    private fun rotationDeg(): Int = (display?.rotation ?: Surface.ROTATION_0) * 90

    private fun copyLog() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("PhoneLock", RecLog.lines.joinToString("\n")))
        Toast.makeText(this, "Журнал скопирован", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        freshLaunch = savedInstanceState == null
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent {
            MaterialTheme { Root() }
        }
    }

    @Composable
    private fun Root() {
        var unlocked by remember { mutableStateOf(!Prefs.hasPin(this@MainActivity)) }
        if (!unlocked) {
            PinGate(onUnlocked = { unlocked = true })
        } else {
            Screen()
        }
    }

    /** Экран-засов перед настройками. См. описание логики PIN'ов вверху файла. */
    @Composable
    private fun PinGate(onUnlocked: () -> Unit) {
        val ctx = this@MainActivity
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf(false) }
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("PhoneLock", style = MaterialTheme.typography.headlineMedium)
            Text("Введите PIN", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter { c -> c.isDigit() }.take(12); err = false },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
            if (err) Text("Неверный PIN", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
            Button(
                modifier = Modifier.padding(top = 16.dp),
                onClick = {
                    when {
                        Prefs.checkPin(ctx, pin) -> onUnlocked()
                        Prefs.hasDuressPin(ctx) && Prefs.checkDuressPin(ctx, pin) -> {
                            // Выглядит как обычный вход, но в фоне тихо начинается запись.
                            try {
                                RecordingService.start(ctx, rotationDeg(), bothCameras = true)
                            } catch (_: Throwable) {
                            }
                            onUnlocked()
                        }
                        else -> err = true
                    }
                }
            ) { Text("Войти") }
        }
    }

    @Composable
    private fun Chip(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
        FilterChip(selected = selected, onClick = onClick, enabled = enabled, label = { Text(label) })
    }

    private enum class Page { Main, LockSettings, RecordSettings, Log, Library }

    private fun fmtTime(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Screen() {
        val ctx = this@MainActivity
        val recording = RecordingService.running
        var page by remember { mutableStateOf(Page.Main) }
        var permDenied by remember { mutableStateOf(false) }
        
        // ПЕРЕМЕННЫЕ ДЛЯ ADB
        val scope = rememberCoroutineScope()
        var adbCode by remember { mutableStateOf("") }
        var adbStatus by remember { mutableStateOf("") }

        BackHandler(enabled = page != Page.Main) { page = Page.Main }

        val screenLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { r ->
            val data = r.data
            if (r.resultCode == Activity.RESULT_OK && data != null) {
                RecordingService.attachScreen(ctx, r.resultCode, data)
            } else {
                RecLog.log("Запись экрана: разрешение не дано, продолжаю только с камерами")
            }
        }

        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            val ok = REQUIRED.all { result[it] == true }
            permDenied = !ok
            if (ok) {
                RecordingService.start(ctx, rotationDeg())
                if (Prefs.screenRecording(ctx)) screenLauncher.launch(screenIntent())
            }
        }

        fun startFlow() { launcher.launch(REQUIRED) }

        LaunchedEffect(Unit) {
            if (freshLaunch && Prefs.autoStart(ctx) && !RecordingService.running) startFlow()
            if (isAdmin()) startUnlockService()
        }

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            when (page) {
                Page.Main -> MainPage(
                    recording = recording,
                    permDenied = permDenied,
                    onToggle = { if (recording) RecordingService.stop(ctx) else startFlow() },
                    onAddScreen = { screenLauncher.launch(screenIntent()) },
                    onLockSettings = { page = Page.LockSettings },
                    onRecordSettings = { page = Page.RecordSettings },
                    onLog = { page = Page.Log },
                    onLibrary = { page = Page.Library },
                    
                    // ПЕРЕДАЧА ПАРАМЕТРОВ ADB В MAINPAGE
                    adbCode = adbCode,
                    onAdbCodeChange = { adbCode = it },
                    adbStatus = adbStatus,
                    onConnectAdb = {
                        scope.launch {
                            adbStatus = "Поиск портов..."
                            AdbManager.startDiscovery(ctx)
                            delay(2000)
                            adbStatus = "Сопряжение..."
                            
                            if (AdbManager.pairDevice(adbCode)) {
                                delay(2000)
                                adbStatus = "Настройка прав..."
                                if (AdbManager.setupPrivileges(ctx)) {
                                    ContextCompat.startForegroundService(ctx, Intent(ctx, GpsTrackingService::class.java))
                                    adbStatus = "GPS включен, координаты пишутся!"
                                } else {
                                    adbStatus = "Ошибка выдачи прав"
                                }
                            } else {
                                adbStatus = "Ошибка сопряжения (проверь код)"
                            }
                        }
                    }
                )
                Page.LockSettings -> LockSettingsPage { page = Page.Main }
                Page.RecordSettings -> RecordSettingsPage(recording) { page = Page.Main }
                Page.Log -> LogPage(recording) { page = Page.Main }
                Page.Library -> LibraryPage { page = Page.Main }
            }
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun MainPage(
        recording: Boolean,
        permDenied: Boolean,
        onToggle: () -> Unit,
        onAddScreen: () -> Unit,
        onLockSettings: () -> Unit,
        onRecordSettings: () -> Unit,
        onLog: () -> Unit,
        onLibrary: () -> Unit,
        
        // ПАРАМЕТРЫ ADB
        adbCode: String,
        onAdbCodeChange: (String) -> Unit,
        adbStatus: String,
        onConnectAdb: () -> Unit
    ) {
        val ctx = this@MainActivity
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(recording) {
            while (recording) {
                now = System.currentTimeMillis()
                delay(1000)
            }
        }
        Text(
            text = stringResource(if (recording) R.string.status_recording else R.string.status_idle),
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Text(
            text = if (isAdmin()) "Права администратора: есть, блокировка работает"
            else "Права администратора НЕ выданы — блокировка не сработает (раздел «Блокировка»)",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp)
        )
        if (recording) {
            Text(
                text = fmtTime(now - RecordingService.startedAtMs) +
                    if (RecordingService.screenActive) "  ·  экран пишется" else "  ·  экран не пишется",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        if (permDenied) {
            Text(text = stringResource(R.string.perm_needed), modifier = Modifier.padding(top = 12.dp))
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 16.dp)) {
            Button(onClick = onToggle) { Text(stringResource(if (recording) R.string.btn_stop else R.string.btn_start)) }
            if (recording && !RecordingService.screenActive) {
                OutlinedButton(onClick = onAddScreen) { Text("Добавить запись экрана") }
            }
        }
        if (recording && Prefs.audioEnabled(ctx)) {
            Text(
                text = AudioStatus.text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 16.dp)
            )
            LinearProgressIndicator(progress = { AudioStatus.level }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        }
        RecLog.lines.lastOrNull()?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 16.dp)
            )
        }

        // БЛОК ИНТЕРФЕЙСА ADB
        Text("GPS и ADB", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
        OutlinedTextField(
            value = adbCode,
            onValueChange = onAdbCodeChange,
            label = { Text("6-значный код (Беспроводная отладка)") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Button(
            onClick = onConnectAdb,
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("Включить GPS через ADB")
        }
        if (adbStatus.isNotEmpty()) {
            Text(adbStatus, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 32.dp)) {
            OutlinedButton(onClick = onLibrary) { Text("Записи") }
            OutlinedButton(onClick = onLockSettings) { Text("Блокировка") }
            OutlinedButton(onClick = onRecordSettings) { Text("Настройки записи") }
            OutlinedButton(onClick = onLog) { Text("Журнал и диагностика") }
        }
    }

    // ---------------------------------------------------------------- Блокировка

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun LockSettingsPage(onBack: () -> Unit) {
        val ctx = this@MainActivity
        var adminActive by remember { mutableStateOf(isAdmin()) }
        var shake by remember { mutableStateOf(Prefs.shakeEnabled(ctx)) }
        var sens by remember { mutableFloatStateOf(Prefs.shakeSensitivity(ctx).toFloat()) }
        var photoUnlock by remember { mutableStateOf(Prefs.photoOnScreenOn(ctx)) }
        var photoWrong by remember { mutableStateOf(Prefs.photoOnWrongPassword(ctx)) }
        var afterAttempts by remember { mutableIntStateOf(Prefs.recordAfterWrongAttempts(ctx)) }
        var simAction by remember { mutableStateOf(Prefs.simRemovedAction(ctx)) }
        var hasPin by remember { mutableStateOf(Prefs.hasPin(ctx)) }
        var hasDuress by remember { mutableStateOf(Prefs.hasDuressPin(ctx)) }
        var pinStage by remember { mutableIntStateOf(0) } // 1 настоящий, 2 под принуждением
        var duressVal by remember { mutableStateOf("") }
        var duressErr by remember { mutableStateOf("") }

        OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← Назад") }
        Text("Блокировка", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 12.dp))

        Section("Права администратора")
        Text(
            if (adminActive) "Выданы." else "Без них блокировка и определение неверного кода не работают.",
            style = MaterialTheme.typography.bodyMedium
        )
        if (!adminActive) {
            Button(onClick = { requestAdmin() }, modifier = Modifier.padding(top = 6.dp)) { Text("Выдать права администратора") }
        }

        Section("Быстрый доступ")
        Text(
            "Иконка приложения — мгновенная блокировка. Плитка «PhoneLock» в шторке и виджет 1×1 на " +
                "рабочем столе (долгое нажатие на рабочий стол → Виджеты) — то же самое. Долгое нажатие " +
                "на иконку открывает ярлыки «Настройки», «Экстренная запись» и «Остановить запись».",
            style = MaterialTheme.typography.bodySmall
        )

        Section("Рывок телефона")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Включён", shake, true) { shake = true; Prefs.setShakeEnabled(ctx, true); startUnlockService() }
            Chip("Выключен", !shake, true) { shake = false; Prefs.setShakeEnabled(ctx, false); startUnlockService() }
        }
        if (shake) {
            Label("Чувствительность: ${sens.toInt()} из 10")
            Slider(
                value = sens, onValueChange = { sens = it },
                onValueChangeFinished = { Prefs.setShakeSensitivity(ctx, sens.toInt()); startUnlockService() },
                valueRange = 1f..10f, steps = 8
            )
        }

        Section("Фото при включении экрана")
        Text(
            "Android не даёт узнать именно о неверном вводе ключа на системном экране — это ближайший " +
                "доступный сигнал, срабатывает при КАЖДОМ включении экрана. Во время съёмки Android " +
                "обязательно показывает системный значок камеры — скрыть его нельзя.",
            style = MaterialTheme.typography.bodySmall
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            Chip("Включено", photoUnlock, true) {
                photoUnlock = true
                if (!CameraCapture.hasPermission(ctx)) requestPermissions(arrayOf(Manifest.permission.CAMERA), 2)
                Prefs.setPhotoOnScreenOn(ctx, true)
            }
            Chip("Выключено", !photoUnlock, true) { photoUnlock = false; Prefs.setPhotoOnScreenOn(ctx, false) }
        }
        val count = Prefs.photoCount(ctx)
        Text(
            if (count > 0) "Снимков сделано: $count, последний — ${Prefs.photoLast(ctx)}" else "Снимков ещё не сделано",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )

        Section("Неверный код/рисунок/биометрия на экране блокировки")
        Text(
            "Это честный системный сигнал (DeviceAdminReceiver.onPasswordFailed), а не слежка в обход API.",
            style = MaterialTheme.typography.bodySmall
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            Chip("Фото при каждой неверной попытке: да", photoWrong, true) { photoWrong = true; Prefs.setPhotoOnWrongPassword(ctx, true) }
            Chip("нет", !photoWrong, true) { photoWrong = false; Prefs.setPhotoOnWrongPassword(ctx, false) }
        }
        Label("Начать полную запись (камеры+звук) после скольких подряд неверных попыток")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (n in listOf(0, 1, 3, 5)) {
                Chip(if (n == 0) "Никогда" else "$n", afterAttempts == n, true) {
                    afterAttempts = n; Prefs.setRecordAfterWrongAttempts(ctx, n)
                }
            }
        }

        Section("Извлечение SIM-карты")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Ничего", simAction == "off", true) { simAction = "off"; Prefs.setSimRemovedAction(ctx, "off") }
            Chip("Фото + блокировка", simAction == "photo", true) { simAction = "photo"; Prefs.setSimRemovedAction(ctx, "photo") }
            Chip("Фото + запись + блокировка", simAction == "record", true) { simAction = "record"; Prefs.setSimRemovedAction(ctx, "record") }
        }

        Section("PIN на вход в эти настройки")
        Text(
            if (hasPin) "PIN задан." else "PIN не задан — эти настройки открыты для всех, у кого есть телефон.",
            style = MaterialTheme.typography.bodyMedium
        )
        Button(onClick = { pinStage = 1 }, modifier = Modifier.padding(top = 4.dp)) {
            Text(if (hasPin) "Сменить PIN" else "Задать PIN")
        }
        if (pinStage == 1) {
            if (hasPin) {
                PinAskDialog(onDismiss = { pinStage = 0 }, onOk = { pinStage = 10 })
            } else {
                pinStage = 10
            }
        }
        if (pinStage == 10) {
            PinSetDialog(
                title = "Новый PIN настроек",
                onDismiss = { pinStage = 0 },
                onOk = { pinStage = 0; hasPin = true }
            )
        }

        Section("PIN «под принуждением»")
        Text(
            "Необязательно. Если вас заставляют открыть настройки, введите этот код вместо настоящего — " +
                "экран откроется как обычно (ничего не отключится), но в фоне тихо начнётся запись. " +
                "Должен отличаться от настоящего PIN.",
            style = MaterialTheme.typography.bodySmall
        )
        if (!hasPin) {
            Text("Сначала задайте обычный PIN выше.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        } else {
            Text(
                if (hasDuress) "Задан." else "Не задан.",
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp)
            )
            OutlinedTextField(
                value = duressVal,
                onValueChange = { duressVal = it.filter { c -> c.isDigit() }.take(12); duressErr = "" },
                label = { Text("Новый код под принуждением, 4–12 цифр") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.padding(top = 6.dp)
            )
            if (duressErr.isNotEmpty()) Text(duressErr, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = {
                    when {
                        duressVal.length < 4 -> duressErr = "Минимум 4 цифры"
                        Prefs.checkPin(ctx, duressVal) -> duressErr = "Должен отличаться от настоящего PIN"
                        else -> { Prefs.setDuressPin(ctx, duressVal); hasDuress = true; duressVal = "" }
                    }
                }) { Text("Сохранить") }
                if (hasDuress) {
                    OutlinedButton(onClick = { Prefs.clearDuressPin(ctx); hasDuress = false }) { Text("Удалить") }
                }
            }
        }

        Section("Какое приложение открыть после блокировки")
        Button(onClick = { showAppPicker(ctx) }, modifier = Modifier.padding(top = 4.dp)) { Text("Выбрать приложение") }
        Text(appLabel(ctx), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp))
    }

    private fun appLabel(ctx: android.content.Context): String {
        val component = Prefs.launchComponent(ctx)
        if (!component.isNullOrEmpty()) {
            val cn = ComponentName.unflattenFromString(component)
            return try {
                val info: ApplicationInfo = packageManager.getApplicationInfo(cn!!.packageName, 0)
                "Откроется: ${packageManager.getApplicationLabel(info)} — $component"
            } catch (e: Throwable) {
                "Откроется: $component (не установлено)"
            }
        }
        val pkg = Prefs.launchPkg(ctx) ?: return "Не выбрано — ничего не откроется"
        return try {
            val info: ApplicationInfo = packageManager.getApplicationInfo(pkg, 0)
            "Откроется: ${packageManager.getApplicationLabel(info)} ($pkg)"
        } catch (e: Throwable) {
            "Откроется: $pkg (не установлено)"
        }
    }

    private fun showAppPicker(ctx: android.content.Context) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val labels = mutableListOf("Не открывать ничего")
        val pkgs = mutableListOf<String?>(null)
        apps.forEach { labels.add(it.loadLabel(packageManager).toString()); pkgs.add(it.activityInfo.packageName) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Открывать при блокировке")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) Prefs.setLaunchPkg(ctx, null) else Prefs.setLaunchPkg(ctx, pkgs[which])
                recreate()
            }
            .show()
    }

    // ---------------------------------------------------------------- Настройки записи

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun RecordSettingsPage(recording: Boolean, onBack: () -> Unit) {
        val ctx = this@MainActivity
        var batteryOk by remember { mutableStateOf(batteryFree()) }
        var overlayOn by remember { mutableStateOf(overlayOk()) }

        var camera by remember { mutableStateOf(Prefs.cameraChoice(ctx)) }
        var segMin by remember { mutableIntStateOf(Prefs.segmentMinutes(ctx)) }
        var audioOn by remember { mutableStateOf(Prefs.audioEnabled(ctx)) }
        var source by remember { mutableIntStateOf(Prefs.audioSource(ctx)) }
        var autoStart by remember { mutableStateOf(Prefs.autoStart(ctx)) }
        var audioTarget by remember { mutableStateOf(Prefs.audioCamera(ctx)) }
        var screenOn by remember { mutableStateOf(Prefs.screenRecording(ctx)) }
        var prompt by remember { mutableStateOf(Prefs.screenPrompt(ctx)) }

        OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← Назад") }
        Text("Настройки записи", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 12.dp))
        if (recording) {
            Text("Пока идёт запись, часть настроек недоступна.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }

        Section("Видео")
        Label("Камера")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Основная", camera == "back", !recording) { camera = "back"; Prefs.setCameraChoice(ctx, "back") }
            Chip("Фронтальная", camera == "front", !recording) { camera = "front"; Prefs.setCameraChoice(ctx, "front") }
            Chip("Обе (если можно)", camera == "both", !recording) { camera = "both"; Prefs.setCameraChoice(ctx, "both") }
        }
        Label("Длина файла, минут")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (m in listOf(1, 5, 10, 30, 0)) {
                Chip(if (m == 0) "Без разбивки" else "$m", segMin == m, !recording) { segMin = m; Prefs.setSegmentMinutes(ctx, m) }
            }
        }

        Section("Экран")
        Label("Записывать экран при обычном старте (кнопкой «Начать запись»)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Да", screenOn, !recording) { screenOn = true; Prefs.setScreenRecording(ctx, true) }
            Chip("Нет", !screenOn, !recording) { screenOn = false; Prefs.setScreenRecording(ctx, false) }
        }
        Text(
            "Экстренная запись (плитка/виджет/панич-ярлык) пишет только камеры и звук — экран требует " +
                "обязательного системного окна подтверждения, которое Android показывает при каждом старте " +
                "и которое ничем нельзя обойти или сделать тихим.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
        Label("После разблокировки, если Android оборвал запись экрана")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Ничего", prompt == "off", true) { prompt = "off"; Prefs.setScreenPrompt(ctx, "off") }
            Chip("Маленькое уведомление", prompt == "notify", true) { prompt = "notify"; Prefs.setScreenPrompt(ctx, "notify") }
            Chip("Сразу большое окно", prompt == "window", true) { prompt = "window"; Prefs.setScreenPrompt(ctx, "window") }
        }

        Section("Звук")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Включён", audioOn, !recording) { audioOn = true; Prefs.setAudioEnabled(ctx, true) }
            Chip("Выключен", !audioOn, !recording) { audioOn = false; Prefs.setAudioEnabled(ctx, false) }
        }
        if (audioOn) {
            Label("В какое видео писать звук")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Во все видео", audioTarget == "both", !recording) { audioTarget = "both"; Prefs.setAudioCamera(ctx, "both") }
                Chip("Только основное", audioTarget == "back", !recording) { audioTarget = "back"; Prefs.setAudioCamera(ctx, "back") }
                Chip("Только фронтальное", audioTarget == "front", !recording) { audioTarget = "front"; Prefs.setAudioCamera(ctx, "front") }
            }
            Label("Источник звука")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AudioPipeline.SOURCES.forEachIndexed { idx, s ->
                    Chip(s.second, source == idx, !recording) { source = idx; Prefs.setAudioSource(ctx, idx) }
                }
            }
        }

        Section("Запуск")
        Label("Начинать запись при открытии приложения (кнопкой/иконкой, не плиткой-паникой)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Да", autoStart, true) { autoStart = true; Prefs.setAutoStart(ctx, true) }
            Chip("Нет", !autoStart, true) { autoStart = false; Prefs.setAutoStart(ctx, false) }
        }

        Section("Защита от остановки системой")
        Text(
            text = if (batteryOk) "Экономия заряда для приложения отключена: хорошо."
            else "Экономия заряда включена: система может остановить запись. Нажми первую кнопку и разреши.",
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp)
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !batteryOk, onClick = { askBatteryFree(); batteryOk = batteryFree() }) { Text("Не ограничивать в фоне") }
            Button(onClick = { openPowerSettings() }) { Text("Экономия заряда (Xiaomi)") }
            Button(onClick = { openAutostart() }) { Text("Автозапуск") }
            Button(enabled = !overlayOn, onClick = { askOverlay(); overlayOn = overlayOk() }) {
                Text(if (overlayOn) "Окно экрана сразу: включено" else "Окно экрана сразу после разблокировки")
            }
        }
        Text(
            text = "В экономии заряда выбери «Нет ограничений», в автозапуске включи приложение. " +
                "Ещё закрепи приложение в списке недавних (замок на карточке). HyperOS/MIUI особенно " +
                "любят убивать фоновые службы без этого.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun LogPage(recording: Boolean, onBack: () -> Unit) {
        val ctx = this@MainActivity
        var clearing by remember { mutableStateOf(false) }
        var left by remember { mutableIntStateOf(0) }
        LaunchedEffect(clearing) {
            if (clearing) {
                for (i in CLEAR_SECONDS downTo 1) { left = i; delay(1000) }
                RecLog.clear()
                clearing = false
            }
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← Назад") }
        Text("Журнал и диагностика", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 12.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            Button(enabled = !recording && !Diagnostics.running, onClick = { Diagnostics.run(ctx) }) {
                Text(if (Diagnostics.running) "Проверяю..." else "Диагностика камер")
            }
            Button(onClick = { copyLog() }) { Text("Скопировать журнал") }
            OutlinedButton(onClick = { clearing = !clearing }) {
                Text(if (clearing) "Отменить очистку ($left с)" else "Очистить журнал")
            }
        }
        Text(
            "Очищается только список на экране. Файлы журналов остаются в папке Documents/PhoneLock.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            "Запуск этого окна: ${Prefs.lastLaunch(ctx) ?: "-"}",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            "Последнее действие блокировки:\n${Prefs.lastAction(ctx) ?: "ещё не было"}",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
        RecLog.lines.takeLast(150).forEach { line ->
            Text(
                text = line, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }

    @Composable
    private fun Section(title: String) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 28.dp))
    }

    @Composable
    private fun Label(text: String) {
        Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp))
    }

    companion object {
        private const val CLEAR_SECONDS = 12
        private val REQUIRED = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.READ_PHONE_STATE
        )
    }
}
