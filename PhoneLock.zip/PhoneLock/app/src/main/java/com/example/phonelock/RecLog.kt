package com.example.phonelock

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Журнал событий: показывается на главном экране и дублируется в файл-журнал сессии. */
object RecLog {
    var lines by mutableStateOf<List<String>>(emptyList())
        private set

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** Очищает только список на экране. Файлы-журналы в Documents/PhoneLock не трогаем. */
    @Synchronized
    fun clear() {
        lines = emptyList()
    }

    @Synchronized
    fun log(msg: String) {
        Log.i("PhoneLock", msg)
        lines = (lines + "${fmt.format(Date())} $msg").takeLast(300)
        EventJournal.write(msg)
    }
}
