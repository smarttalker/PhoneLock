package com.example.phonelock

import android.app.Activity
import android.os.Bundle

/**
 * Невидимая activity для ярлыка «Экстренная запись» (долгое нажатие на иконку) и для
 * плитки/виджета: блокирует экран и сразу запускает полную запись (камеры + звук).
 * Никакого всплывающего окна не показывает — только обязательное системное уведомление
 * «Идёт запись», которое Android не даёт скрыть ни одному приложению.
 */
class PanicActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LockAction.run(this, record = true)
        finish()
    }
}
