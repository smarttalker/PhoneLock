package com.example.phonelock

import android.app.Activity
import android.os.Bundle

/**
 * Невидимая activity для ярлыка «Экстренная запись» (долгое нажатие на иконку) и для
 * плитки/виджета: блокирует экран и сразу запускает полную запись (камеры + звук).
 * Никакого всплывающего окна не показывает — только обязательное системное уведомление
 * «Идёт запись», которое Android не даёт скрыть ни одному приложению.
 */
class PanicActivity : Activity() {
    companion object {
        const val EXTRA_LOCK = "lock"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // EXTRA_LOCK = false (плитка в шторке): биометрию отключаем и пишем, но экран не блокируем.
        LockAction.run(this, record = true, lockScreen = intent?.getBooleanExtra(EXTRA_LOCK, true) ?: true)
        finish()
    }
}
