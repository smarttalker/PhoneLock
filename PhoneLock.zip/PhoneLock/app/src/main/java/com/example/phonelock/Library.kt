package com.example.phonelock

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.GregorianCalendar
import java.util.Locale

/** Один файл записи в Movies/PhoneLock. */
class Rec(
    val id: Long,
    val uri: Uri,
    val name: String,
    val tag: String,
    val startMs: Long,
    var durMs: Long,
    val size: Long
)

/** Файлы одного периода записи: камеры и экран, пересекающиеся по времени. */
class Group(val recs: List<Rec>, val startMs: Long, val endMs: Long) {
    val size get() = recs.sumOf { it.size }
}

object Library {
    private val rx = Regex("""PhoneLock_(back|front|screen)_(\d{4})_(\d{2})_(\d{2})_(\d{2})_(\d{2})_(\d{2})\.mp4""")
    private const val MOOF = 0x6D6F6F66
    private const val TRAF = 0x74726166
    private const val TFHD = 0x74666864
    private const val TFDT = 0x74666474
    private const val TRUN = 0x7472756E

    /** Все видео приложения. Длительность считается из самого файла и запоминается. */
    fun load(ctx: Context): List<Rec> {
        val res = ArrayList<Rec>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(
                base, proj,
                "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/PhoneLock%"),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: continue
                    val size = c.getLong(2)
                    val dur = c.getLong(3)
                    val added = c.getLong(4) * 1000
                    val m = rx.matchEntire(name)
                    val tag: String
                    val start: Long
                    if (m != null) {
                        tag = m.groupValues[1]
                        val g = m.groupValues.drop(2).map { it.toInt() }
                        start = GregorianCalendar(g[0], g[1] - 1, g[2], g[3], g[4], g[5]).timeInMillis
                    } else {
                        tag = "?"
                        start = added
                    }
                    val r = Rec(id, ContentUris.withAppendedId(base, id), name, tag, start, dur, size)
                    r.durMs = durationMs(ctx, r)
                    res += r
                }
            }
        } catch (e: Exception) {
            RecLog.log("Список записей: ${e.message}")
        }
        return res
    }

    /** Склеивает файлы в периоды: новый период начинается, если пауза между файлами больше 10 секунд. Новые сверху. */
    fun group(recs: List<Rec>): List<Group> {
        val sorted = recs.sortedBy { it.startMs }
        val out = ArrayList<Group>()
        var cur = ArrayList<Rec>()
        var end = 0L
        for (r in sorted) {
            val rEnd = r.startMs + maxOf(r.durMs, 1000L)
            if (cur.isNotEmpty() && r.startMs > end + 10_000L) {
                out += Group(cur, cur.minOf { it.startMs }, end)
                cur = ArrayList()
                end = 0L
            }
            cur += r
            end = maxOf(end, rEnd)
        }
        if (cur.isNotEmpty()) out += Group(cur, cur.minOf { it.startMs }, end)
        return out.reversed()
    }

    fun tagName(tag: String) = when (tag) {
        "back" -> "основная"
        "front" -> "фронтальная"
        "screen" -> "экран"
        else -> "?"
    }

    // ---------- длительность из фрагментов файла ----------

    private fun durationMs(ctx: Context, r: Rec): Long {
        val cache = ctx.getSharedPreferences("durcache", Context.MODE_PRIVATE)
        val key = "${r.name}:${r.size}"
        if (cache.contains(key)) return cache.getLong(key, 0L)
        var d = -1L
        try {
            ctx.contentResolver.openFileDescriptor(r.uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).use { d = scan(it.channel) }
            }
        } catch (_: Exception) {
        }
        if (d <= 0) d = r.durMs
        if (d > 0) cache.edit().putLong(key, d).apply()
        return d
    }

    private fun scan(ch: FileChannel): Long {
        val size = ch.size()
        var pos = 0L
        var end = 0L
        val hdr = ByteBuffer.allocate(16)
        while (pos + 8 <= size) {
            hdr.clear()
            val n = ch.read(hdr, pos)
            if (n < 8) break
            hdr.flip()
            var bsize = hdr.int.toLong() and 0xFFFFFFFFL
            val type = hdr.int
            var hlen = 8
            if (bsize == 1L && n >= 16) {
                bsize = hdr.long
                hlen = 16
            } else if (bsize == 0L) {
                bsize = size - pos
            }
            if (bsize < hlen) break
            if (type == MOOF) {
                val len = (bsize - hlen).coerceAtMost(1_000_000L).toInt()
                val b = ByteBuffer.allocate(len)
                ch.read(b, pos + hlen)
                b.flip()
                val e = moofEnd(b)
                if (e > 0) end = e
            }
            pos += bsize
        }
        return end
    }

    /** Конец видеодорожки (№1) в миллисекундах: начало фрагмента плюс сумма длительностей кадров. */
    private fun moofEnd(b: ByteBuffer): Long {
        var p = 0
        while (p + 8 <= b.limit()) {
            val sz = b.getInt(p)
            val type = b.getInt(p + 4)
            if (sz < 8) break
            if (type == TRAF) {
                val e = trafEnd(b, p + 8, minOf(p + sz, b.limit()))
                if (e > 0) return e
            }
            p += sz
        }
        return 0
    }

    private fun trafEnd(b: ByteBuffer, from: Int, to: Int): Long {
        var track = -1
        var base = 0L
        var sum = 0L
        var p = from
        while (p + 8 <= to) {
            val sz = b.getInt(p)
            val type = b.getInt(p + 4)
            if (sz < 8) break
            val q = p + 8
            when (type) {
                TFHD -> track = b.getInt(q + 4)
                TFDT -> base = if ((b.get(q).toInt() and 0xFF) == 1) b.getLong(q + 4) else b.getInt(q + 4).toLong() and 0xFFFFFFFFL
                TRUN -> {
                    val flags = b.getInt(q) and 0xFFFFFF
                    val count = b.getInt(q + 4)
                    var o = q + 8
                    if (flags and 0x1 != 0) o += 4
                    if (flags and 0x4 != 0) o += 4
                    val per = (if (flags and 0x100 != 0) 4 else 0) + (if (flags and 0x200 != 0) 4 else 0) +
                        (if (flags and 0x400 != 0) 4 else 0) + (if (flags and 0x800 != 0) 4 else 0)
                    for (i in 0 until count) {
                        if (flags and 0x100 != 0 && o + 4 <= to) sum += b.getInt(o).toLong() and 0xFFFFFFFFL
                        o += per
                    }
                }
            }
            p += sz
        }
        return if (track == 1) (base + sum) * 1000L / 90000L else 0L
    }
}

private fun fmtDate(ms: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(java.util.Date(ms))
private fun fmtClock(ms: Long) = SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date(ms))
private fun fmtDur(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
}
private fun fmtSize(b: Long) = if (b >= 1L shl 30) "%.1f ГБ".format(b / 1073741824.0) else "%d МБ".format(b / 1048576)

private fun openExternal(ctx: Context, r: Rec) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(r.uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "Нет приложения для просмотра", Toast.LENGTH_SHORT).show()
    }
}

/** Страница «Записи»: периоды записи, просмотр всех видео периода вместе, удаление периода. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LibraryPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var groups by remember { mutableStateOf(emptyList<Group>()) }
    var loading by remember { mutableStateOf(true) }
    var watching by remember { mutableStateOf<Group?>(null) }
    val open = remember { mutableStateListOf<Long>() }
    var delGroup by remember { mutableStateOf<Group?>(null) }
    var pinStage by remember { mutableIntStateOf(0) } // 0 - нет окна, 1 - спросить пароль, 2 - задать пароль

    fun reload() {
        scope.launch {
            loading = true
            val l = withContext(Dispatchers.IO) { Library.load(ctx) }
            groups = Library.group(l)
            loading = false
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { reload() }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { reload() }

    fun doDelete(g: Group) {
        try {
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, g.recs.map { it.uri })
            delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } catch (e: Exception) {
            RecLog.log("Удаление: ${e.message}")
        }
    }

    if (pinStage == 1) PinAskDialog(onDismiss = { pinStage = 0 }, onOk = { pinStage = 0; delGroup?.let { doDelete(it) } })
    if (pinStage == 2) PinSetDialog(onDismiss = { pinStage = 0 }, onOk = { pinStage = 0; delGroup?.let { doDelete(it) } })

    LaunchedEffect(Unit) {
        reload()
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ctx.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) permLauncher.launch(perm)
    }

    val w = watching
    if (w != null) {
        BackHandler { watching = null }
        PlayerPage(w) { watching = null }
        return
    }

    OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← Назад") }
    Text("Записи", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 12.dp))
    val files = groups.sumOf { it.recs.size }
    Text(
        if (loading) "Считаю длительность файлов..."
        else "Периодов: ${groups.size}, файлов: $files, занято ${fmtSize(groups.sumOf { it.size })}.",
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(top = 4.dp)
    )
    Text(
        "Период это все камеры и экран, снятые в одно время. Выбирать отдельные файлы не нужно: " +
            "«Смотреть» открывает всё сразу. Удаление защищено паролем (его можно сменить в настройках), потом ещё спросит система.",
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(top = 4.dp)
    )

    groups.forEach { g ->
        Column(modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
            Text(
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date(g.startMs)) + "  " +
                    fmtClock(g.startMs) + " – " + fmtClock(g.endMs) + "  (" + fmtDur(g.endMs - g.startMs) + ")",
                style = MaterialTheme.typography.titleMedium
            )
            val kinds = listOf("back", "front", "screen", "?").mapNotNull { t ->
                val c = g.recs.count { it.tag == t }
                if (c > 0) "${Library.tagName(t)} ×$c" else null
            }
            Text(kinds.joinToString(", ") + "  ·  " + fmtSize(g.size), style = MaterialTheme.typography.bodySmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = { watching = g }) { Text("Смотреть") }
                OutlinedButton(onClick = {
                    delGroup = g
                    pinStage = if (Prefs.hasPin(ctx)) 1 else 2
                }) { Text("Удалить период") }
                OutlinedButton(onClick = { if (g.startMs in open) open.remove(g.startMs) else open.add(g.startMs) }) {
                    Text(if (g.startMs in open) "Скрыть файлы" else "Файлы")
                }
            }
            if (g.startMs in open) {
                g.recs.sortedBy { it.startMs }.forEach { r ->
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${Library.tagName(r.tag)}  ${fmtDate(r.startMs)}", style = MaterialTheme.typography.bodySmall)
                            Text(fmtDur(r.durMs) + "  ·  " + fmtSize(r.size), style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(onClick = { openExternal(ctx, r) }) { Text("Открыть") }
                    }
                }
            }
        }
    }
}

/** Просмотр периода: по одному окну на камеру и экран, общая шкала времени, файлы подряд меняются сами. */
@Composable
private fun PlayerPage(g: Group, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lanes = remember(g) {
        listOf("back", "front", "screen", "?").map { t -> g.recs.filter { it.tag == t }.sortedBy { it.startMs } }
            .filter { it.isNotEmpty() }
    }
    val n = lanes.size
    val base = g.startMs
    val totalMs = (g.endMs - g.startMs).coerceAtLeast(1L)
    val curSeg = remember { IntArray(n) { -1 } }
    var posMs by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }

    val players = remember {
        Array(n) { l ->
            ExoPlayer.Builder(ctx).build().also { p ->
                // звук только от первого окна, чтобы не было каши из трёх одинаковых дорожек
                p.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                    l == 0
                )
                p.volume = if (l == 0) 1f else 0f
                p.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        RecLog.log("Просмотр: окно ${l + 1}: ${error.errorCodeName}: ${error.message}")
                    }
                })
            }
        }
    }

    fun applyLane(l: Int, seek: Boolean) {
        val p = players[l]
        val segs = lanes[l]
        val t = base + posMs
        val idx = segs.indexOfFirst { t >= it.startMs && t < it.startMs + it.durMs }
        if (idx < 0) {
            p.playWhenReady = false
            return
        }
        val local = t - segs[idx].startMs
        if (curSeg[l] != idx) {
            curSeg[l] = idx
            p.setMediaItem(MediaItem.fromUri(segs[idx].uri), local)
            p.prepare()
            p.playWhenReady = playing
            return
        }
        if (seek) p.seekTo(local)
        p.playWhenReady = playing
    }

    fun applyAll(seek: Boolean) {
        for (l in 0 until n) applyLane(l, seek)
    }

    LaunchedEffect(Unit) {
        // показать первый кадр каждого окна
        applyAll(true)
    }

    LaunchedEffect(playing) {
        applyAll(false)
        while (playing) {
            delay(250)
            posMs += 250
            // уточняем по первому окну, чтобы не накапливалась погрешность
            val s0 = curSeg[0]
            val p0 = players[0]
            if (s0 >= 0 && p0.isPlaying) {
                posMs = lanes[0][s0].startMs - base + p0.currentPosition
            }
            if (posMs >= totalMs) {
                playing = false
                posMs = totalMs
            }
            applyAll(false)
        }
        for (p in players) p.playWhenReady = false
    }

    DisposableEffect(Unit) {
        onDispose { for (p in players) try { p.release() } catch (_: Exception) {} }
    }

    OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← К списку") }
    Text(
        "Период " + fmtClock(g.startMs) + " – " + fmtClock(g.endMs),
        style = MaterialTheme.typography.titleLarge,
        modifier = Modifier.padding(top = 8.dp)
    )
    Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        lanes.forEachIndexed { l, segs ->
            Column(modifier = Modifier.weight(1f)) {
                Text(Library.tagName(segs[0].tag), style = MaterialTheme.typography.labelSmall)
                AndroidView(
                    factory = { c -> TextureView(c).also { players[l].setVideoTextureView(it) } },
                    modifier = Modifier.fillMaxWidth().height(300.dp)
                )
            }
        }
    }
    Slider(
        value = posMs.toFloat().coerceIn(0f, totalMs.toFloat()),
        onValueChange = { posMs = it.toLong(); applyAll(true) },
        valueRange = 0f..totalMs.toFloat(),
        modifier = Modifier.padding(top = 8.dp)
    )
    Text(
        fmtDate(base + posMs) + "   (" + fmtDur(posMs) + " из " + fmtDur(totalMs) + ")",
        style = MaterialTheme.typography.bodySmall
    )
    Button(onClick = { playing = !playing }, modifier = Modifier.padding(top = 8.dp)) {
        Text(if (playing) "Пауза" else "Играть")
    }
    Text(
        "Звук идёт от первого окна слева. Если какое-то окно чёрное, в этот момент в нём нет записи (например, экран был заблокирован).",
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(top = 4.dp)
    )
}
