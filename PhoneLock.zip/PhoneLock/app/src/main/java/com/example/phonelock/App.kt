package com.example.phonelock

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            RecordingService.CHANNEL_ID,
            getString(R.string.channel_recording),
            NotificationManager.IMPORTANCE_LOW
        )
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
        // Подчищаем «осиротевшее» уведомление «Идёт запись», если оно могло остаться
        // от предыдущей установки/версии приложения (сервис, который его показывал,
        // уже не существует, поэтому сам убрать его не может).
        if (!RecordingService.running) nm.cancel(RecordingService.NOTIFICATION_ID)
    }
}
