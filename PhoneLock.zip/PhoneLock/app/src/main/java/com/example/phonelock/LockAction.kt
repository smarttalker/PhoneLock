package com.example.phonelock

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Общая логика: отключить биометрию, заблокировать экран и, если попросили, начать запись. */
object LockAction {

    private fun save(context: Context, text: String) {
        val time = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date())
        Prefs.setLastAction(context, "$time\n$text")
    }

    /**
     * Возвращает false, если права администратора не выданы.
     * [record] — сразу запустить полную запись (камеры+звук), как при панике.
     * [lockScreen] = false — экран НЕ блокируется (биометрия при этом уже отключена): блокировать
     * будет сам человек кнопкой питания, и разблокировать после этого можно только графическим ключом/PIN.
     */
    fun run(context: Context, startService: Boolean = true, record: Boolean = false, lockScreen: Boolean = true): Boolean {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, AdminReceiver::class.java)

        if (!dpm.isAdminActive(admin)) {
            save(context, "Права администратора не выданы")
            return false
        }

        val log = StringBuilder()

        if (startService) {
            try {
                val svc = Intent(context, UnlockService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc)
                else context.startService(svc)
                log.append("1. Сервис запущен: OK\n")
            } catch (e: Throwable) {
                log.append("1. Сервис НЕ запущен: ${e.javaClass.simpleName}: ${e.message}\n")
            }
        } else {
            log.append("1. Сервис уже работает\n")
        }

        val bio = BiometricGuard.disable(context)
        log.append("2. Биометрия: $bio\n")

        if (lockScreen) {
            try {
                dpm.lockNow()
                log.append("3. Экран заблокирован: OK\n")
            } catch (e: Throwable) {
                log.append("3. Блокировка НЕ сработала: ${e.javaClass.simpleName}: ${e.message}\n")
            }
        } else {
            log.append("3. Экран не блокирую: жду кнопку питания\n")
        }

        val component = if (lockScreen) Prefs.launchComponent(context) else null
        val pkg = if (lockScreen) Prefs.launchPkg(context) else null
        if (!component.isNullOrEmpty()) {
            // Запуск конкретного компонента (не просто главного экрана
            // приложения): так сработает даже если приложение уже открыто
            // в фоне — система всё равно вызовет onCreate() именно этой
            // Activity, как при тапе по отдельному ярлыку на рабочем столе.
            try {
                val cn = ComponentName.unflattenFromString(component)
                if (cn != null) {
                    val launch = Intent().apply {
                        setComponent(cn)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    context.startActivity(launch)
                    log.append("4. Открыт компонент: $component\n")
                } else {
                    log.append("4. Не распознан компонент: $component\n")
                }
            } catch (e: Throwable) {
                log.append("4. Не удалось открыть компонент $component: ${e.javaClass.simpleName}: ${e.message}\n")
            }
        } else if (!pkg.isNullOrEmpty()) {
            try {
                val launch = context.packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    log.append("4. Открыто приложение: $pkg\n")
                } else {
                    log.append("4. Приложение не найдено: $pkg\n")
                }
            } catch (e: Throwable) {
                log.append("4. Не удалось открыть $pkg: ${e.javaClass.simpleName}: ${e.message}\n")
            }
        }

        if (record) {
            try {
                RecordingService.start(context, 0, bothCameras = true)
                log.append("5. Запись запущена")
            } catch (e: Throwable) {
                log.append("5. Запись НЕ запущена: ${e.javaClass.simpleName}: ${e.message}")
            }
        }

        save(context, log.toString())
        for (line in log.lines()) if (line.isNotBlank()) RecLog.log("Блокировка: ${line.trim()}")
        return true
    }
}
