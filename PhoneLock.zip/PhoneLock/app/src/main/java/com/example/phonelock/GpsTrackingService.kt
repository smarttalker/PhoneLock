package com.example.phonelock

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.*
import android.os.*
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class GpsTrackingService : Service(), LocationListener {
    private lateinit var lm: LocationManager

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        startForeground(99, buildNotification("Ожидание GPS..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, this)
        } catch (e: SecurityException) { stopSelf() }
        return START_STICKY
    }

    override fun onLocationChanged(location: Location) {
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val line = """{"lat":${location.latitude},"lon":${location.longitude},"time":"$time"}"""
        val dir = getExternalFilesDir(null) ?: filesDir
        File(dir, "gps_log.jsonl").appendText(line + "\n")
        updateNotification("${location.latitude}, ${location.longitude}")
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "gps_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "GPS Трекер", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("PhoneLock GPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(99, buildNotification(text))
    }

    override fun onProviderDisabled(provider: String) { stopSelf() }
    override fun onProviderEnabled(provider: String) {}
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null
}