package com.example.phonelock

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Пишет координаты. Порядок источников (режим «Авто»):
 *  1) сеть — Wi‑Fi и вышки сотовой связи (NETWORK_PROVIDER);
 *  2) GPS-приёмник — если сети нет, она выключена, включён авиарежим или сеть давно молчит.
 * В режиме «Только GPS» сеть не используется вообще.
 */
class GpsTrackingService : Service() {
    private lateinit var lm: LocationManager
    private val main = Handler(Looper.getMainLooper())
    private val listeners = HashMap<String, LocationListener>()
    private var lastNetworkAt = 0L
    private var lastSavedAt = 0L
    private var lastSrc = ""

    private val heartbeat = object : Runnable {
        override fun run() {
            ensureLocationOn(this@GpsTrackingService)
            val ago = if (lastSavedAt == 0L) "ещё не было" else "${(System.currentTimeMillis() - lastSavedAt) / 1000} с назад ($lastSrc)"
            GpsLog.log("Статус: последняя точка $ago; ${providersState(this@GpsTrackingService)}")
            main.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            startForeground(99, buildNotification("Ожидание координат..."))
        } catch (e: Throwable) {
            GpsLog.log("Служба GPS не запустилась как foreground: ${e.javaClass.simpleName}: ${e.message}")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (listeners.isEmpty()) startListening()
        return START_STICKY
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            GpsLog.log("Нет разрешения на геолокацию — трекинг остановлен")
            stopSelf()
            return
        }
        ensureLocationOn(this)
        val mode = Prefs.gpsSource(this)
        GpsLog.log("Трекинг запущен. Режим: ${if (mode == "gps") "только GPS" else "авто (сеть → GPS)"}; ${providersState(this)}")
        val providers = if (mode == "gps") listOf(LocationManager.GPS_PROVIDER)
        else listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
        for (p in providers) {
            if (!lm.allProviders.contains(p)) {
                GpsLog.log("Источник $p не поддерживается этим телефоном")
                continue
            }
            val l = object : LocationListener {
                override fun onLocationChanged(location: Location) = handleFix(location)
                override fun onProviderDisabled(provider: String) {
                    GpsLog.log("Источник $provider выключен")
                    ensureLocationOn(this@GpsTrackingService)
                }
                override fun onProviderEnabled(provider: String) { GpsLog.log("Источник $provider включён") }
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }
            try {
                lm.requestLocationUpdates(p, if (p == LocationManager.GPS_PROVIDER) 5000L else 10_000L, 0f, l, Looper.getMainLooper())
                listeners[p] = l
            } catch (e: Throwable) {
                GpsLog.log("Не удалось подписаться на $p: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        if (listeners.isEmpty()) {
            GpsLog.log("Ни один источник не подключился — трекинг остановлен")
            stopSelf()
            return
        }
        main.removeCallbacks(heartbeat)
        main.postDelayed(heartbeat, 60_000L)
    }

    private fun handleFix(loc: Location) {
        val now = System.currentTimeMillis()
        val mode = Prefs.gpsSource(this)
        when (loc.provider) {
            LocationManager.NETWORK_PROVIDER -> {
                if (mode == "gps") return
                lastNetworkAt = now
                record(loc, "network")
            }
            LocationManager.GPS_PROVIDER -> {
                // пока сеть даёт координаты, GPS не дублируем
                if (mode == "auto" && now - lastNetworkAt < 30_000L) return
                record(loc, "gps")
            }
        }
    }

    private fun record(loc: Location, src: String) {
        saveToFile(this, loc, src)
        lastSavedAt = System.currentTimeMillis()
        lastSrc = src
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(99, buildNotification("$src: ${loc.latitude}, ${loc.longitude}"))
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "gps_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "GPS Трекер", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("PhoneLock GPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
    }

    override fun onDestroy() {
        main.removeCallbacks(heartbeat)
        for ((_, l) in listeners) try { lm.removeUpdates(l) } catch (_: Exception) {}
        listeners.clear()
        GpsLog.log("Трекинг остановлен")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        /**
         * Если системная геолокация выключена — включает её сама (нужно право WRITE_SECURE_SETTINGS,
         * которое один раз выдаётся кнопкой «Включить GPS через ADB»). Возвращает true, если геолокация включена.
         */
        fun ensureLocationOn(context: Context): Boolean {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (lm.isLocationEnabled) return true
            if (context.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) {
                GpsLog.log("Геолокация выключена, а права включать её самому нет — нажми «Включить GPS через ADB»")
                return false
            }
            return try {
                Settings.Secure.putInt(context.contentResolver, "location_mode", 3)
                GpsLog.log("Геолокация была выключена — включил сам")
                true
            } catch (e: Throwable) {
                GpsLog.log("Не удалось включить геолокацию: ${e.javaClass.simpleName}: ${e.message}")
                false
            }
        }

        fun logFile(context: Context): File {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            return File(dir, "gps_log.jsonl")
        }

        fun saveToFile(context: Context, location: Location, source: String) {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(location.time))
            val line = """{"lat":${location.latitude},"lon":${location.longitude},"acc":${location.accuracy},"time":"$time","src":"$source"}"""
            try {
                logFile(context).appendText(line + "\n")
            } catch (e: Exception) {
                GpsLog.log("Не удалось записать в файл: ${e.message}")
            }
            GpsLog.log("Точка ($source): ${location.latitude}, ${location.longitude} ±${location.accuracy.toInt()} м")
            RecLog.log("GPS ($source): ${location.latitude}, ${location.longitude}")
        }

        /** Последние [n] строк файла с координатами. */
        fun tail(context: Context, n: Int): String {
            val f = logFile(context)
            if (!f.exists()) return ""
            return try { f.readLines().takeLast(n).joinToString("\n") } catch (_: Exception) { "" }
        }

        fun pointCount(context: Context): Int {
            val f = logFile(context)
            return if (f.exists()) try { f.useLines { it.count() } } catch (_: Exception) { 0 } else 0
        }

        fun providersState(context: Context): String {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            fun st(p: String) = try {
                if (!lm.allProviders.contains(p)) "нет" else if (lm.isProviderEnabled(p)) "вкл" else "выкл"
            } catch (_: Exception) { "?" }
            val air = try { Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (_: Exception) { false }
            return "сеть=${st(LocationManager.NETWORK_PROVIDER)}, GPS=${st(LocationManager.GPS_PROVIDER)}, авиарежим=${if (air) "да" else "нет"}"
        }

        /** Разовая запись координаты (при разблокировке): сначала сеть, затем GPS. */
        fun recordOnce(context: Context) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                GpsLog.log("Разблокировка: нет разрешения на геолокацию")
                return
            }
            ensureLocationOn(context)
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = if (Prefs.gpsSource(context) == "gps") listOf(LocationManager.GPS_PROVIDER)
            else listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            GpsLog.log("Разблокировка: ищу координату; ${providersState(context)}")

            for (p in providers) {
                val last = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null }
                if (last != null && System.currentTimeMillis() - last.time < 5 * 60_000L) {
                    saveToFile(context, last, "unlock_cache_$p")
                    break
                }
            }

            val gotNetwork = AtomicBoolean(false)
            for (p in providers) {
                try {
                    if (!lm.isProviderEnabled(p)) {
                        GpsLog.log("Разблокировка: $p выключен")
                        continue
                    }
                    lm.getCurrentLocation(p, null, ContextCompat.getMainExecutor(context)) { loc ->
                        if (loc == null) {
                            GpsLog.log("Разблокировка: $p не дал координату")
                        } else if (p == LocationManager.NETWORK_PROVIDER) {
                            gotNetwork.set(true)
                            saveToFile(context, loc, "unlock_fresh_$p")
                        } else if (!gotNetwork.get()) {
                            saveToFile(context, loc, "unlock_fresh_$p")
                        }
                    }
                } catch (e: Throwable) {
                    GpsLog.log("Разблокировка: ошибка $p: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
        }
    }
}
