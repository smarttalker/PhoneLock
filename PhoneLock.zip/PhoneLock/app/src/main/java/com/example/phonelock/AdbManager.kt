package com.example.phonelock

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.flyfishxu.kadb.Kadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AdbManager {
    private var pairingPort: Int? = null
    private var connectPort: Int? = null
    private var nsdManager: NsdManager? = null

    fun startDiscovery(context: Context) {
        if (nsdManager != null) return
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager

        nsdManager?.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onServiceFound(service: NsdServiceInfo) {
                nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(resolved: NsdServiceInfo) { pairingPort = resolved.port; GpsLog.log("ADB: найден порт сопряжения ${resolved.port}") }
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { GpsLog.log("ADB: не удалось определить порт (код $errorCode)") }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(s: String, e: Int) {}
            override fun onStopDiscoveryFailed(s: String, e: Int) {}
            override fun onDiscoveryStarted(s: String) {}
            override fun onDiscoveryStopped(s: String) {}
        })

        nsdManager?.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onServiceFound(service: NsdServiceInfo) {
                nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(resolved: NsdServiceInfo) { connectPort = resolved.port; GpsLog.log("ADB: найден порт подключения ${resolved.port}") }
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { GpsLog.log("ADB: не удалось определить порт (код $errorCode)") }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(s: String, e: Int) {}
            override fun onStopDiscoveryFailed(s: String, e: Int) {}
            override fun onDiscoveryStarted(s: String) {}
            override fun onDiscoveryStopped(s: String) {}
        })
    }

    suspend fun pairDevice(code: String): Boolean = withContext(Dispatchers.IO) {
        val port = pairingPort ?: run {
            GpsLog.log("ADB: порт сопряжения не найден — открой окно «Подключить устройство с помощью кода»")
            return@withContext false
        }
        return@withContext try {
            Kadb.pair("127.0.0.1", port, code)
            GpsLog.log("ADB: сопряжение выполнено")
            true
        } catch (e: Exception) {
            GpsLog.log("ADB: ошибка сопряжения: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    suspend fun setupPrivileges(context: Context): Boolean = withContext(Dispatchers.IO) {
        val port = connectPort ?: run {
            GpsLog.log("ADB: порт подключения не найден — включена ли «Беспроводная отладка»?")
            return@withContext false
        }
        return@withContext try {
            Kadb.create("127.0.0.1", port).use { kadb ->
                // Включаем GPS и убираем окно подтверждения записи экрана
                val r1 = kadb.shell("settings put secure location_mode 3")
                GpsLog.log("ADB: геолокация включена (код ${r1.exitCode})")
                val r2 = kadb.shell("appops set ${context.packageName} PROJECT_MEDIA allow")
                GpsLog.log("ADB: окно записи экрана отключено (код ${r2.exitCode})")
                true
            }
        } catch (e: Exception) {
            GpsLog.log("ADB: ошибка выдачи прав: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }
}