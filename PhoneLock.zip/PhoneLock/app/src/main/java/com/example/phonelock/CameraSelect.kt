package com.example.phonelock

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Range
import android.util.Size

object CameraSelect {

    data class Result(
        val back: String?,
        val front: String?,
        val concurrent: Boolean,
        val note: String
    )

    /** Выбирает основную и фронтальную камеры. Если система объявляет пару, умеющую работать вместе, берёт её. */
    fun select(ctx: Context): Result {
        val cm = ctx.getSystemService(CameraManager::class.java)
        return try {
            val ids = cm.cameraIdList.toList()
            val facing = { id: String -> cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) }
            val backs = ids.filter { facing(it) == CameraCharacteristics.LENS_FACING_BACK }
            val fronts = ids.filter { facing(it) == CameraCharacteristics.LENS_FACING_FRONT }

            var found: Result? = null
            for (set in cm.concurrentCameraIds) {
                val b = backs.firstOrNull { it in set }
                val f = fronts.firstOrNull { it in set }
                if (b != null && f != null) {
                    found = Result(b, f, true, "Две камеры одновременно: поддерживается (основная $b, фронтальная $f)")
                    break
                }
            }
            found ?: Result(
                backs.firstOrNull(),
                fronts.firstOrNull(),
                false,
                "Система не объявляет режим двух камер. Пробую открыть обе (основная ${backs.firstOrNull()}, фронтальная ${fronts.firstOrNull()})"
            )
        } catch (e: Exception) {
            Result(null, null, false, "Ошибка поиска камер: ${e.message}")
        }
    }

    /** Размер буфера камеры: 16:9, не шире maxW; если такого нет, ближайший меньший. */
    fun pickSize(chars: CameraCharacteristics, maxW: Int = 1280): Size {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        return sizes.filter { it.width <= maxW && it.width * 9 == it.height * 16 }.maxByOrNull { it.width }
            ?: sizes.filter { it.width <= maxW }.maxByOrNull { it.width * it.height }
            ?: sizes.minByOrNull { it.width * it.height }!!
    }

    /** Диапазон частоты кадров, содержащий fps: сначала фиксированный [24,24], затем самый узкий с нижней границей повыше. */
    fun pickFps(chars: CameraCharacteristics, fps: Int): Range<Int>? {
        val ranges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: return null
        val containing = ranges
            .filter { it.lower <= fps && it.upper >= fps }
            .sortedWith(compareByDescending<Range<Int>> { it.lower }.thenBy { it.upper })
        return containing.firstOrNull() ?: ranges.minByOrNull { Math.abs(it.upper - fps) }
    }
}
