package com.example.phonelock

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground-сервис записи: держит камеры, микрофон и запись экрана, пока телефон заблокирован или занят звонком.
 * Камеры и звук стартуют сразу; запись экрана подключается позже, когда пользователь подтвердит системное окно.
 * Показывает обязательное уведомление «Идёт запись» с кнопкой остановки.
 */
class RecordingService : Service() {

    private class Plan(val cams: List<Pair<String, String>>, val audio: Boolean)

    private val pipelines = mutableListOf<CameraPipeline>()
    private var audio: AudioPipeline? = null
    @Volatile private var screen: ScreenPipeline? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var screenReceiver: BroadcastReceiver? = null
    private val main = Handler(Looper.getMainLooper())

    // Параметры текущей сессии: нужны, когда запись экрана подключается позже
    private var curStamp = ""
    private var curSegMs = 0L
    private var curAudioToAll = true
    private var textCams = ""
    private var textAudio = ""

    @Volatile private var stopping = false

    // Android 16 сам обрывает запись экрана при блокировке. После разблокировки просим подтвердить заново.
    @Volatile private var screenLost = false
    private var reconsentNotified = false

    // Подстраховка: раз в пару секунд сверяем состояние экрана, если системное уведомление пропустили
    private val screenPoll = object : Runnable {
        override fun run() {
            if (!running || stopping) return
            val sc = screen
            val pm = getSystemService(PowerManager::class.java)
            val km = getSystemService(KeyguardManager::class.java)
            val unlocked = pm.isInteractive && !km.isKeyguardLocked
            if (sc != null) {
                if (unlocked) sc.resume() else sc.pause()
            } else if (screenLost && unlocked && !reconsentNotified && Prefs.screenPrompt(this@RecordingService) != "off") {
                askScreenAgain()
            }
            main.postDelayed(this, 1500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopRecording()
        } else if (action == ACTION_SCREEN && intent != null) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
            if (data != null) attachScreen(code, data, 0)
        } else {
            startRecording(intent?.getIntExtra(EXTRA_ROTATION, 0) ?: 0, intent?.getBooleanExtra(EXTRA_BOTH, false) ?: false)
        }
        // Камеру из фона система запустить не даёт, поэтому после убийства процесса сами не перезапускаемся
        return START_NOT_STICKY
    }

    private fun makePlan(sel: CameraSelect.Result, forceBoth: Boolean): Plan {
        val back = sel.back
        val front = sel.front
        val cams = mutableListOf<Pair<String, String>>()
        when (if (forceBoth) "both" else Prefs.cameraChoice(this)) {
            "front" -> if (front != null) cams += "front" to front else if (back != null) cams += "back" to back
            "both" -> {
                if (back != null) cams += "back" to back
                if (front != null) cams += "front" to front
            }
            else -> if (back != null) cams += "back" to back else if (front != null) cams += "front" to front
        }
        val useAudio = Prefs.audioEnabled(this)
        textCams = when {
            cams.size >= 2 -> "обе камеры"
            cams.firstOrNull()?.first == "front" -> "фронтальная камера"
            else -> "основная камера"
        }
        textAudio = if (useAudio) ", со звуком" else ", без звука"
        return Plan(cams, useAudio)
    }

    private fun notifText(withScreen: Boolean): String =
        "Идёт запись: $textCams" + (if (withScreen) ", экран" else "") + textAudio

    private fun cameraMicTypes(): Int =
        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE

    private fun startRecording(rotationDeg: Int, forceBoth: Boolean = false) {
        if (running) return
        val sel = CameraSelect.select(this)
        val plan = makePlan(sel, forceBoth)
        try {
            startForeground(NOTIFICATION_ID, buildNotification(notifText(false)), cameraMicTypes())
        } catch (e: Exception) {
            RecLog.log("Не удалось запустить сервис: ${e.message}")
            stopSelf()
            return
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            RecLog.log("Нет разрешения на камеру")
            finishService()
            return
        }
        running = true
        startedAtMs = System.currentTimeMillis()

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        EventJournal.open(this, stamp)
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (_: Exception) {
            "?"
        }
        EventJournal.write("PhoneLock $version, ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
        RecLog.log("Запись начата. ${notifText(false)}")
        RecLog.log(sel.note)

        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PhoneLock:rec").also { it.acquire() }
        } catch (e: Exception) {
            RecLog.log("Wake lock: ${e.message}")
        }

        CallWatcher.start(this)
        registerScreenReceiver()
        main.postDelayed(screenPoll, 1500)

        if (plan.cams.isEmpty()) {
            RecLog.log("Камеры не найдены")
            stopRecording()
            return
        }

        // Звук стартует первым, чтобы к началу видеофайла его формат уже был известен
        var audioPipe: AudioPipeline? = null
        if (plan.audio) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                audioPipe = AudioPipeline(Prefs.audioSource(this)).also { it.start() }
                audio = audioPipe
            } else {
                RecLog.log("Нет разрешения на микрофон, пишу без звука")
            }
        }
        val wantedAudio = Prefs.audioCamera(this)
        val audioToAll = wantedAudio == "both" || plan.cams.none { it.first == wantedAudio }
        val segMs = Prefs.segmentMinutes(this) * 60_000L
        curStamp = stamp
        curSegMs = segMs
        curAudioToAll = audioToAll

        var delay = 0L
        // При двух камерах сначала открываем обе, и только потом начинаем съёмку
        val gate = if (plan.cams.size > 1) OpenGate(plan.cams.size) else null
        // Основная камера стартует первой
        plan.cams.forEach { (tag, id) ->
            main.postDelayed({
                if (!running || stopping) return@postDelayed
                try {
                    val p = CameraPipeline(this, id, tag, rotationDeg, segMs, stamp, gate) { onPipelineGaveUp(it) }
                    synchronized(pipelines) { pipelines.add(p) }
                    if (audioToAll || tag == wantedAudio) audioPipe?.attach(p.writer)
                    p.start()
                } catch (e: Exception) {
                    RecLog.log("$tag: не удалось запустить: ${e.message}")
                }
            }, delay)
            delay += 800
        }
    }

    /** Подключает запись экрана после того, как пользователь подтвердил системное окно. */
    private fun attachScreen(code: Int, data: Intent, attempt: Int) {
        if (stopping) return
        if (!running) {
            // сервис ещё запускается: пробуем снова чуть позже
            if (attempt < 10) main.postDelayed({ attachScreen(code, data, attempt + 1) }, 500)
            return
        }
        if (screen != null) return
        try {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(notifText(true)),
                cameraMicTypes() or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } catch (e: Exception) {
            RecLog.log("Запись экрана: не удалось получить доступ: ${e.message}")
            return
        }
        startScreen(code, data, curSegMs, curStamp, if (curAudioToAll) audio else null)
    }

    private fun startScreen(code: Int, data: Intent, segMs: Long, stamp: String, audioPipe: AudioPipeline?) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val projection = mpm.getMediaProjection(code, data)
                ?: throw IllegalStateException("система не выдала доступ к экрану")
            val pm = getSystemService(PowerManager::class.java)
            val km = getSystemService(KeyguardManager::class.java)
            val locked = !pm.isInteractive || km.isKeyguardLocked
            val sp = ScreenPipeline(this, projection, segMs, stamp) { main.post { onScreenStopped() } }
            screen = sp
            screenActive = true
            screenLost = false
            reconsentNotified = false
            getSystemService(NotificationManager::class.java).cancel(NOTIFICATION_RECONSENT)
            audioPipe?.attach(sp.writer)
            sp.start(locked)
        } catch (e: Exception) {
            RecLog.log("Запись экрана не запустилась: ${e.message}")
            screen = null
        }
    }

    private fun onScreenStopped() {
        val s = screen ?: return
        screen = null
        screenActive = false
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val wasLocked = !pm.isInteractive || km.isKeyguardLocked
        if (wasLocked && running && !stopping) {
            screenLost = true
            reconsentNotified = false
            EventJournal.write("Запись экрана прервана системой при блокировке телефона (так устроен Android 16). Камеры и звук продолжают писаться.")
        }
        Thread { s.stopBlocking() }.start()
    }

    /** Уведомление «продолжить запись экрана»: по нажатию открывается системное окно подтверждения. */
    private fun askScreenAgain() {
        reconsentNotified = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ASK, "Продолжить запись экрана", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = Intent(this, ScreenConsentActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            this, 2, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL_ASK)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Запись экрана: нажми, чтобы продолжить")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFICATION_RECONSENT, n)
        if (Prefs.screenPrompt(this) == "window") {
            // большое окно сразу; Android разрешает это из фона только при включённом праве «поверх других окон»
            try {
                startActivity(open)
                RecLog.log("Запись экрана: показываю окно подтверждения")
            } catch (e: Exception) {
                RecLog.log("Запись экрана: окно не открылось (${e.message}), жду нажатия на уведомление")
            }
        } else {
            RecLog.log("Запись экрана: жду, пока ты подтвердишь продолжение (уведомление)")
        }
    }

    private fun registerScreenReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        RecLog.log("Экран выключен")
                        screen?.pause()
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        RecLog.log("Экран включён")
                        val km = getSystemService(KeyguardManager::class.java)
                        if (!km.isKeyguardLocked) screen?.resume()
                    }
                    Intent.ACTION_USER_PRESENT -> {
                        RecLog.log("Телефон разблокирован")
                        screen?.resume()
                    }
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        try {
            ContextCompat.registerReceiver(this, r, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            screenReceiver = r
        } catch (e: Exception) {
            RecLog.log("Слежение за экраном недоступно: ${e.message}")
        }
    }

    private fun unregisterScreenReceiver() {
        try {
            screenReceiver?.let { unregisterReceiver(it) }
        } catch (_: Exception) {
        }
        screenReceiver = null
    }

    private fun onPipelineGaveUp(tag: String) {
        Thread {
            val p = synchronized(pipelines) {
                pipelines.firstOrNull { it.tag == tag }?.also { pipelines.remove(it) }
            }
            p?.stopBlocking()
            val empty = synchronized(pipelines) { pipelines.isEmpty() }
            if (empty && !stopping) main.post { stopRecording() }
        }.start()
    }

    private fun stopRecording() {
        if (stopping) return
        stopping = true
        val list = synchronized(pipelines) { pipelines.toList().also { pipelines.clear() } }
        val a = audio
        audio = null
        val sc = screen
        screen = null
        Thread {
            // сначала звук, потом камеры и экран: всё заканчивается почти одновременно
            a?.stopBlocking()
            list.forEach { it.stopBlocking() }
            sc?.stopBlocking()
            if (list.isNotEmpty() || a != null || sc != null) RecLog.log("Запись остановлена")
            Hasher.awaitIdle(20_000)
            EventJournal.close()
            main.post { finishService() }
        }.start()
    }

    private fun finishService() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
        CallWatcher.stop(this)
        unregisterScreenReceiver()
        main.removeCallbacks(screenPoll)
        getSystemService(NotificationManager::class.java).cancel(NOTIFICATION_RECONSENT)
        screenLost = false
        screenActive = false
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        stopping = false
    }

    override fun onDestroy() {
        val left = synchronized(pipelines) { pipelines.toList().also { pipelines.clear() } }
        val a = audio
        audio = null
        val sc = screen
        screen = null
        if (left.isNotEmpty() || a != null || sc != null) {
            Thread {
                a?.stopBlocking()
                left.forEach { it.stopBlocking() }
                sc?.stopBlocking()
                Hasher.awaitIdle(20_000)
                EventJournal.close()
            }.start()
        }
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        CallWatcher.stop(this)
        unregisterScreenReceiver()
        main.removeCallbacks(screenPoll)
        screenActive = false
        running = false
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, RecordingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null, getString(R.string.notif_stop), stopIntent
                ).build()
            )
            .build()
    }

    companion object {
        const val CHANNEL_ID = "recording"
        const val NOTIFICATION_ID = 1
        const val NOTIFICATION_RECONSENT = 2
        const val CHANNEL_ASK = "ask_screen"
        const val ACTION_START = "com.example.phonelock.action.START"
        const val ACTION_STOP = "com.example.phonelock.action.STOP"
        const val ACTION_SCREEN = "com.example.phonelock.action.SCREEN"
        const val EXTRA_ROTATION = "rotation_deg"
        const val EXTRA_BOTH = "both_cameras"
        const val EXTRA_RESULT_CODE = "projection_code"
        const val EXTRA_RESULT_DATA = "projection_data"

        /** Идёт ли запись. Состояние Compose, поэтому экран обновляется сам. */
        var running by mutableStateOf(false)
            private set

        /** Идёт ли сейчас запись экрана. */
        var screenActive by mutableStateOf(false)
            private set

        /** Когда началась запись (мс), для секундомера на экране. */
        @Volatile var startedAtMs = 0L

        fun start(context: Context, rotationDeg: Int = 0, bothCameras: Boolean = false) {
            context.startForegroundService(
                Intent(context, RecordingService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_ROTATION, rotationDeg)
                    .putExtra(EXTRA_BOTH, bothCameras)
            )
        }

        /** Передаёт сервису разрешение на запись экрана, полученное от системы. */
        fun attachScreen(context: Context, resultCode: Int, data: Intent) {
            context.startService(
                Intent(context, RecordingService::class.java)
                    .setAction(ACTION_SCREEN)
                    .putExtra(EXTRA_RESULT_CODE, resultCode)
                    .putExtra(EXTRA_RESULT_DATA, data)
            )
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, RecordingService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
