package com.example.phonelock

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.flyfishxu.kadb.Kadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AdbManager {
    private var pairingPort: Int? = null
    private var connectPort: Int? = null
    private var nsdManager: NsdManager? = null

    fun startDiscovery(context: Context) {
        if (nsdManager != null) return
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager

        nsdManager?.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onServiceFound(service: NsdServiceInfo) {
                nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(resolved: NsdServiceInfo) { pairingPort = resolved.port }
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(s: String, e: Int) {}
            override fun onStopDiscoveryFailed(s: String, e: Int) {}
            override fun onDiscoveryStarted(s: String) {}
            override fun onDiscoveryStopped(s: String) {}
        })

        nsdManager?.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onServiceFound(service: NsdServiceInfo) {
                nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(resolved: NsdServiceInfo) { connectPort = resolved.port }
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(s: String, e: Int) {}
            override fun onStopDiscoveryFailed(s: String, e: Int) {}
            override fun onDiscoveryStarted(s: String) {}
            override fun onDiscoveryStopped(s: String) {}
        })
    }

    suspend fun pairDevice(code: String): Boolean = withContext(Dispatchers.IO) {
        val port = pairingPort ?: return@withContext false
        return@withContext try {
            Kadb.pair("127.0.0.1", port, code)
            true
        } catch (e: Exception) { 
            e.printStackTrace()
            false 
        }
    }

    suspend fun setupPrivileges(context: Context): Boolean = withContext(Dispatchers.IO) {
        val port = connectPort ?: return@withContext false
        return@withContext try {
            Kadb.create("127.0.0.1", port).use { kadb ->
                // Включаем GPS и убираем окно подтверждения записи экрана
                kadb.shell("settings put secure location_mode 3")
                kadb.shell("appops set ${context.packageName} PROJECT_MEDIA allow")
                true
            }
        } catch (e: Exception) { 
            e.printStackTrace()
            false 
        }
    }
}