package com.example.phonelock

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class GpsTrackingService : Service(), LocationListener {
    private lateinit var lm: LocationManager

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        startForeground(99, buildNotification("Ожидание GPS..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, this)
        } catch (e: SecurityException) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onLocationChanged(location: Location) {
        saveToFile(this, location, "tracking")
        updateNotification("${location.latitude}, ${location.longitude}")
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "gps_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "GPS Трекер", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("PhoneLock GPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(99, buildNotification(text))
    }

    override fun onProviderDisabled(provider: String) { stopSelf() }
    override fun onProviderEnabled(provider: String) {}
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun saveToFile(context: Context, location: Location, source: String) {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(location.time))
            val line = """{"lat":${location.latitude},"lon":${location.longitude},"acc":${location.accuracy},"time":"$time","src":"$source"}"""
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            File(dir, "gps_log.jsonl").appendText(line + "\n")
            RecLog.log("GPS ($source): ${location.latitude}, ${location.longitude}")
        }

        fun recordOnce(context: Context) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            
            val last = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (e: Exception) { null }
            if (last != null && System.currentTimeMillis() - last.time < 1000 * 60 * 5) {
                saveToFile(context, last, "unlock_cache")
            }

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    saveToFile(context, location, "unlock_fresh")
                    try { lm.removeUpdates(this) } catch (e: Exception) {}
                }
                override fun onProviderDisabled(provider: String) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }
            try {
                lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper())
            } catch (e: Exception) {}
        }
    }
}
