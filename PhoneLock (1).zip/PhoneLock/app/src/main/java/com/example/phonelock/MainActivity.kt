package com.example.phonelock

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Surface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.activity.ComponentActivity
import kotlinx.coroutines.delay
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var freshLaunch = true

    private fun isAdmin(): Boolean {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        return dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
    }

    private fun batteryFree(): Boolean = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun tryStart(vararg intents: Intent) {
        for (i in intents) {
            try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
        }
        Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
    }

    private fun overlayOk(): Boolean = Settings.canDrawOverlays(this)
    private fun askOverlay() = tryStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), appDetails())
    private fun appDetails() = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    private fun askBatteryFree() = tryStart(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")), Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    private fun openAutostart() = tryStart(Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")), Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT), appDetails())
    private fun openPowerSettings() = tryStart(Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY").setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")).putExtra("package_name", packageName).putExtra("package_label", getString(R.string.app_name)), appDetails())

    private fun requestAdmin() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this@MainActivity, AdminReceiver::class.java))
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Нужно, чтобы мгновенно блокировать экран и видеть неверные попытки ввода кода.")
        }
        startActivity(intent)
    }

    private fun startUnlockService() {
        try {
            val svc = Intent(this, UnlockService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        } catch (e: Throwable) { e.printStackTrace() }
    }

    private fun screenIntent(): Intent {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        return if (Build.VERSION.SDK_INT >= 34) mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()) else mpm.createScreenCaptureIntent()
    }

    private fun rotationDeg(): Int = (display?.rotation ?: Surface.ROTATION_0) * 90

    private fun copyLog() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("PhoneLock", RecLog.lines.joinToString("\n")))
        Toast.makeText(this, "Журнал скопирован", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        freshLaunch = savedInstanceState == null
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme { Root() } }
    }

    @Composable
    private fun Root() {
        var unlocked by remember { mutableStateOf(!Prefs.hasPin(this@MainActivity)) }
        if (!unlocked) PinGate(onUnlocked = { unlocked = true }) else Screen()
    }

    @Composable
    private fun PinGate(onUnlocked: () -> Unit) {
        val ctx = this@MainActivity
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf(false) }
        Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("PhoneLock", style = MaterialTheme.typography.headlineMedium)
            Text("Введите PIN", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter { c -> c.isDigit() }.take(12); err = false },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
            if (err) Text("Неверный PIN", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
            Button(modifier = Modifier.padding(top = 16.dp), onClick = {
                when {
                    Prefs.checkPin(ctx, pin) -> onUnlocked()
                    Prefs.hasDuressPin(ctx) && Prefs.checkDuressPin(ctx, pin) -> {
                        try { RecordingService.start(ctx, rotationDeg(), bothCameras = true) } catch (_: Throwable) {}
                        onUnlocked()
                    }
                    else -> err = true
                }
            }) { Text("Войти") }
        }
    }

    @Composable
    private fun Chip(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
        FilterChip(selected = selected, onClick = onClick, enabled = enabled, label = { Text(label) })
    }

    private enum class Page { Main, LockSettings, RecordSettings, Log, Library }

    private fun fmtTime(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Screen() {
        val ctx = this@MainActivity
        val recording = RecordingService.running
        var page by remember { mutableStateOf(Page.Main) }
        var permDenied by remember { mutableStateOf(false) }
        
        val scope = rememberCoroutineScope()
        var adbCode by remember { mutableStateOf("") }
        var adbStatus by remember { mutableStateOf("") }

        BackHandler(enabled = page != Page.Main) { page = Page.Main }

        val screenLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == Activity.RESULT_OK && data != null) RecordingService.attachScreen(ctx, r.resultCode, data)
            else RecLog.log("Запись экрана: разрешение не дано")
        }

        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val ok = REQUIRED.all { result[it] == true }
            permDenied = !ok
            if (ok) {
                RecordingService.start(ctx, rotationDeg())
                if (Prefs.screenRecording(ctx)) screenLauncher.launch(screenIntent())
            }
        }

        fun startFlow() { launcher.launch(REQUIRED) }

        LaunchedEffect(Unit) {
            if (freshLaunch && Prefs.autoStart(ctx) && !RecordingService.running) startFlow()
            if (isAdmin()) startUnlockService()
        }

        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Top, horizontalAlignment = Alignment.Start) {
            when (page) {
                Page.Main -> MainPage(
                    recording = recording, permDenied = permDenied,
                    onToggle = { if (recording) RecordingService.stop(ctx) else startFlow() },
                    onAddScreen = { screenLauncher.launch(screenIntent()) },
                    onLockSettings = { page = Page.LockSettings },
                    onRecordSettings = { page = Page.RecordSettings },
                    onLog = { page = Page.Log },
                    onLibrary = { page = Page.Library },
                    adbCode = adbCode,
                    onAdbCodeChange = { adbCode = it },
                    adbStatus = adbStatus,
                    onConnectAdb = {
                        scope.launch {
                            adbStatus = "Поиск портов..."
                            AdbManager.startDiscovery(ctx)
                            delay(2000)
                            adbStatus = "Сопряжение..."
                            if (AdbManager.pairDevice(adbCode)) {
                                delay(2000)
                                adbStatus = "Настройка прав..."
                                if (AdbManager.setupPrivileges(ctx)) {
                                    ContextCompat.startForegroundService(ctx, Intent(ctx, GpsTrackingService::class.java))
                                    adbStatus = "GPS включен, окно экрана скрыто!"
                                } else {
                                    adbStatus = "Ошибка выдачи прав"
                                }
                            } else {
                                adbStatus = "Ошибка сопряжения (проверь код)"
                            }
                        }
                    }
                )
                Page.LockSettings -> LockSettingsPage { page = Page.Main }
                Page.RecordSettings -> RecordSettingsPage(recording) { page = Page.Main }
                Page.Log -> LogPage(recording) { page = Page.Main }
                Page.Library -> LibraryPage { page = Page.Main }
            }
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun MainPage(
        recording: Boolean, permDenied: Boolean, onToggle: () -> Unit, onAddScreen: () -> Unit,
        onLockSettings: () -> Unit, onRecordSettings: () -> Unit, onLog: () -> Unit, onLibrary: () -> Unit,
        adbCode: String, onAdbCodeChange: (String) -> Unit, adbStatus: String, onConnectAdb: () -> Unit
    ) {
        val ctx = this@MainActivity
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(recording) { while (recording) { now = System.currentTimeMillis(); delay(1000) } }
        
        Text(text = stringResource(if (recording) R.string.status_recording else R.string.status_idle), style = MaterialTheme.typography.headlineMedium, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Text(text = if (isAdmin()) "Права администратора: есть" else "Права администратора НЕ выданы", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
        
        if (recording) {
            Text(text = fmtTime(now - RecordingService.startedAtMs) + if (RecordingService.screenActive) " · экран пишется" else " · экран не пишется", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
        }
        if (permDenied) Text(text = stringResource(R.string.perm_needed), modifier = Modifier.padding(top = 12.dp))
        
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 16.dp)) {
            Button(onClick = onToggle) { Text(stringResource(if (recording) R.string.btn_stop else R.string.btn_start)) }
            if (recording && !RecordingService.screenActive) OutlinedButton(onClick = onAddScreen) { Text("Добавить запись экрана") }
        }
        if (recording && Prefs.audioEnabled(ctx)) {
            Text(text = AudioStatus.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 16.dp))
            LinearProgressIndicator(progress = { AudioStatus.level }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        }
        RecLog.lines.lastOrNull()?.let {
            Text(text = it, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 16.dp))
        }

        Text("GPS и ADB", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
        OutlinedTextField(
            value = adbCode, onValueChange = onAdbCodeChange,
            label = { Text("6-значный код (Беспроводная отладка)") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Button(onClick = onConnectAdb, modifier = Modifier.padding(top = 8.dp)) { Text("Включить GPS через ADB") }
        if (adbStatus.isNotEmpty()) Text(adbStatus, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 32.dp)) {
            OutlinedButton(onClick = onLibrary) { Text("Записи") }
            OutlinedButton(onClick = onLockSettings) { Text("Блокировка") }
            OutlinedButton(onClick = onRecordSettings) { Text("Настройки записи") }
            OutlinedButton(onClick = onLog) { Text("Журнал и диагностика") }
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun RecordSettingsPage(recording: Boolean, onBack: () -> Unit) {
        val ctx = this@MainActivity
        var batteryOk by remember { mutableStateOf(batteryFree()) }
        var overlayOn by remember { mutableStateOf(overlayOk()) }
        var camera by remember { mutableStateOf(Prefs.cameraChoice(ctx)) }
        var segMin by remember { mutableIntStateOf(Prefs.segmentMinutes(ctx)) }
        var audioOn by remember { mutableStateOf(Prefs.audioEnabled(ctx)) }
        var source by remember { mutableIntStateOf(Prefs.audioSource(ctx)) }
        var autoStart by remember { mutableStateOf(Prefs.autoStart(ctx)) }
        var audioTarget by remember { mutableStateOf(Prefs.audioCamera(ctx)) }
        var screenOn by remember { mutableStateOf(Prefs.screenRecording(ctx)) }
        var prompt by remember { mutableStateOf(Prefs.screenPrompt(ctx)) }
        var gpsOn by remember { mutableStateOf(Prefs.gpsEnabled(ctx)) }

        OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("← Назад") }
        Text("Настройки записи", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 12.dp))

        Section("Видео")
        Label("Камера")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Основная", camera == "back", !recording) { camera = "back"; Prefs.setCameraChoice(ctx, "back") }
            Chip("Фронтальная", camera == "front", !recording) { camera = "front"; Prefs.setCameraChoice(ctx, "front") }
            Chip("Обе (если можно)", camera == "both", !recording) { camera = "both"; Prefs.setCameraChoice(ctx, "both") }
        }
        Label("Длина файла, минут")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (m in listOf(1, 5, 10, 30, 0)) {
                Chip(if (m == 0) "Без разбивки" else "$m", segMin == m, !recording) { segMin = m; Prefs.setSegmentMinutes(ctx, m) }
            }
        }
        
        Section("GPS-трекинг")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Включен", gpsOn, !recording) { gpsOn = true; Prefs.setGpsEnabled(ctx, true) }
            Chip("Выключен", !gpsOn, !recording) { gpsOn = false; Prefs.setGpsEnabled(ctx, false) }
        }
        Text("Координаты пишутся в файл gps_log.jsonl", style = MaterialTheme.typography.bodySmall)

        Section("Экран")
        Label("Записывать экран при обычном старте")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Да", screenOn, !recording) { screenOn = true; Prefs.setScreenRecording(ctx, true) }
            Chip("Нет", !screenOn, !recording) { screenOn = false; Prefs.setScreenRecording(ctx, false) }
        }

        Section("Звук")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Включён", audioOn, !recording) { audioOn = true; Prefs.setAudioEnabled(ctx, true) }
            Chip("Выключен", !audioOn, !recording) { audioOn = false; Prefs.setAudioEnabled(ctx, false) }
        }

        Section("Запуск")
        Label("Начинать запись при открытии приложения")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Да", autoStart, true) { autoStart = true; Prefs.setAutoStart(ctx, true) }
            Chip("Нет", !autoStart, true) { autoStart = false; Prefs.setAutoStart(ctx, false) }
        }

        Section("Защита от остановки системой")
        Text(text = if (batteryOk) "Экономия заряда отключена: хорошо." else "Экономия заряда включена: система может остановить запись.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !batteryOk, onClick = { askBatteryFree(); batteryOk = batteryFree() }) { Text("Не ограничивать в фоне") }
            Button(onClick = { openPowerSettings() }) { Text("Экономия (Xiaomi)") }
            Button(onClick = { openAutostart() }) { Text("Автозапуск") }
            Button(enabled = !overlayOn, onClick = { askOverlay(); overlayOn = overlayOk() }) {
                Text(if (overlayOn) "Окно экрана: вкл" else "Окно экрана: выкл")
            }
        }
    }

    @Composable private fun Section(title: String) { Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 28.dp)) }
    @Composable private fun Label(text: String) { Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)) }

    companion object {
        private val REQUIRED = arrayOf(
            Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }
}

