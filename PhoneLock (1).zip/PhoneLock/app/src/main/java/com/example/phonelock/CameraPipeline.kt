package com.example.phonelock

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Общий «шлагбаум» для нескольких камер: съёмка стартует, когда все камеры открыты (или отказались). */
class OpenGate(expected: Int) {
    private val latch = CountDownLatch(expected)

    fun arrive() {
        latch.countDown()
    }

    fun await(timeoutMs: Long) {
        try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        }
    }
}

/**
 * Одна камера: Camera2 -> SurfaceTexture -> OpenGL (поворот + таймкод) -> MediaCodec (H.264) -> SegmentWriter (MP4).
 * При потере камеры пытается открыть её снова, файл при этом не закрывается.
 */
class CameraPipeline(
    private val ctx: Context,
    private val cameraId: String,
    val tag: String,
    displayRotationDeg: Int,
    segmentMs: Long,
    sessionStamp: String,
    private val gate: OpenGate?,
    private val onGaveUp: (String) -> Unit
) {
    private val cm = ctx.getSystemService(CameraManager::class.java)
    private val chars = cm.getCameraCharacteristics(cameraId)
    private val isFront = chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
    private val sensor = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    // Сколько градусов по часовой надо повернуть кадр сенсора, чтобы он был «правильной стороной вверх»
    private val rotCw = if (isFront) (sensor + displayRotationDeg) % 360 else (sensor - displayRotationDeg + 360) % 360
    private val src = CameraSelect.pickSize(chars)
    private val swap = rotCw % 180 != 0
    private val outW = if (swap) src.height else src.width
    private val outH = if (swap) src.width else src.height
    private val fpsRange = CameraSelect.pickFps(chars, FPS)

    /** Файл-писатель этой камеры: сюда же подключается звук. */
    val writer = SegmentWriter(ctx, sessionStamp, tag, segmentMs)

    // Если камера отдаёт время кадров в тех же часах, что и система, берём его; иначе время прихода кадра
    private val tsRealtime = chars.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
        CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME

    private val glThread = HandlerThread("gl-$tag").also { it.start() }
    private val glHandler = Handler(glThread.looper)
    private val camThread = HandlerThread("cam-$tag").also { it.start() }
    private val camHandler = Handler(camThread.looper)
    private val camExecutor = Executor { camHandler.post(it) }
    private val encThread = HandlerThread("enc-$tag").also { it.start() }
    private val encHandler = Handler(encThread.looper)

    @Volatile private var running = false
    private val stopped = AtomicBoolean(false)
    private val arrived = AtomicBoolean(false)

    /** Сообщает «моя камера открыта (или не откроется)»: съёмка начнётся, когда это сделают все камеры. */
    private fun arriveOnce() {
        if (arrived.compareAndSet(false, true)) gate?.arrive()
    }
    private val eosLatch = CountDownLatch(1)

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var egl: EglCore? = null
    private var renderer: FrameRenderer? = null
    private var st: SurfaceTexture? = null
    private var camSurface: Surface? = null

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var everOpened = false
    private var failures = 0

    private val texMat = FloatArray(16)
    private var texLogged = false
    private var nextTs = 0L
    private var frameErrors = 0

    fun start() {
        running = true
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.setCallback(object : MediaCodec.Callback() {
            override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {}

            override fun onOutputBufferAvailable(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
                try {
                    val buf = codec.getOutputBuffer(index)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig) writer.write(buf, info)
                    codec.releaseOutputBuffer(index, false)
                } catch (e: Exception) {
                    RecLog.log("$tag: ошибка вывода кодера: ${e.message}")
                }
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    writer.close()
                    eosLatch.countDown()
                }
            }

            override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
                RecLog.log("$tag: ошибка кодера: ${e.message}")
            }

            override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
                writer.setFormat(format)
            }
        }, encHandler)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = enc.createInputSurface()
        enc.start()
        encoder = enc
        glHandler.post { initGl() }
    }

    private fun initGl() {
        try {
            val e = EglCore(inputSurface!!)
            e.makeCurrent()
            egl = e
            val r = FrameRenderer(src.width, src.height, outW, outH, rotCw)
            renderer = r
            val s = SurfaceTexture(r.oesTex)
            s.setDefaultBufferSize(src.width, src.height)
            s.setOnFrameAvailableListener({ onFrame() }, glHandler)
            st = s
            camSurface = Surface(s)
            camHandler.post { openCamera() }
        } catch (e: Exception) {
            RecLog.log("$tag: ошибка OpenGL: ${e.message}")
            onGaveUp(tag)
        }
    }

    private fun shouldRender(ts: Long): Boolean {
        val frameNs = 1_000_000_000L / FPS
        if (nextTs == 0L) {
            nextTs = ts + frameNs
            return true
        }
        if (ts + frameNs / 2 < nextTs) return false
        nextTs += frameNs
        if (ts > nextTs) nextTs = ts + frameNs
        return true
    }

    private fun onFrame() {
        val s = st ?: return
        val e = egl ?: return
        val r = renderer ?: return
        try {
            s.updateTexImage()
            val ts = if (tsRealtime) s.timestamp else SystemClock.elapsedRealtimeNanos()
            if (!shouldRender(ts)) return
            s.getTransformMatrix(texMat)
            if (!texLogged) {
                texLogged = true
                RecLog.log("$tag: матрица кадра ${texMat.take(16).joinToString(" ") { "%.2f".format(it) }}")
            }
            // Некоторые драйверы (фронтальная камера) закладывают поворот в матрицу кадра: поворачиваем сами,
            // поэтому поворот из матрицы убираем и оставляем только обычное отражение по вертикали.
            if (Math.abs(texMat[0]) < 0.5f) {
                java.util.Arrays.fill(texMat, 0f)
                texMat[0] = 1f; texMat[5] = -1f; texMat[10] = 1f; texMat[13] = 1f; texMat[15] = 1f
            }
            r.draw(texMat)
            e.setPresentationTime(ts)
            e.swap()
        } catch (ex: Exception) {
            if (frameErrors++ < 3) RecLog.log("$tag: ошибка кадра: ${ex.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!running) return
        try {
            cm.openCamera(cameraId, camExecutor, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    if (!running) {
                        d.close()
                        return
                    }
                    device = d
                    arriveOnce()
                    val g = gate
                    if (g == null) {
                        createSession(d)
                    } else {
                        // Сначала открываем все камеры, и только потом запускаем съёмку
                        Thread {
                            g.await(5000)
                            camHandler.post { if (running && device === d) createSession(d) }
                        }.start()
                    }
                }

                override fun onDisconnected(d: CameraDevice) {
                    RecLog.log("$tag: камера отключилась")
                    d.close()
                    device = null
                    session = null
                    scheduleReopen()
                }

                override fun onError(d: CameraDevice, error: Int) {
                    RecLog.log("$tag: ошибка камеры, код $error")
                    d.close()
                    device = null
                    session = null
                    scheduleReopen()
                }
            })
        } catch (e: Exception) {
            RecLog.log("$tag: не удалось открыть камеру: ${e.message}")
            scheduleReopen()
        }
    }

    private fun createSession(d: CameraDevice) {
        val surface = camSurface ?: return
        try {
            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                listOf(OutputConfiguration(surface)),
                camExecutor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (!running) {
                            s.close()
                            return
                        }
                        session = s
                        try {
                            val req = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                                addTarget(surface)
                                fpsRange?.let { set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
                                val af = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
                                if (af != null && af.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) {
                                    set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                                }
                            }.build()
                            s.setRepeatingRequest(req, null, camHandler)
                            everOpened = true
                            failures = 0
                            RecLog.log("$tag: камера работает ${src.width}x${src.height} -> ${outW}x$outH, $FPS кадр/с, поворот $rotCw°")
                        } catch (e: Exception) {
                            RecLog.log("$tag: не удалось запустить съёмку: ${e.message}")
                            closeDevice()
                            scheduleReopen()
                        }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        RecLog.log("$tag: камера не приняла настройки")
                        closeDevice()
                        scheduleReopen()
                    }
                }
            )
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            RecLog.log("$tag: ошибка сессии камеры: ${e.message}")
            closeDevice()
            scheduleReopen()
        }
    }

    private fun closeDevice() {
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        session = null
        device = null
    }

    private fun scheduleReopen() {
        arriveOnce()
        if (!running) return
        failures++
        if (!everOpened && failures >= 5) {
            RecLog.log("$tag: камера недоступна, пропускаю её")
            onGaveUp(tag)
            return
        }
        camHandler.postDelayed({ openCamera() }, 2000)
    }

    /** Останавливает камеру, дописывает и закрывает файл. Блокирует поток до нескольких секунд. */
    fun stopBlocking() {
        if (!stopped.compareAndSet(false, true)) return
        arriveOnce()
        running = false
        camHandler.removeCallbacksAndMessages(null)

        val camDone = CountDownLatch(1)
        camHandler.post {
            closeDevice()
            camDone.countDown()
        }
        camDone.await(2, TimeUnit.SECONDS)

        val glDone = CountDownLatch(1)
        glHandler.post {
            try { encoder?.signalEndOfInputStream() } catch (e: Exception) {
                RecLog.log("$tag: конец потока: ${e.message}")
            }
            try { st?.setOnFrameAvailableListener(null) } catch (_: Exception) {}
            try { st?.release() } catch (_: Exception) {}
            try { camSurface?.release() } catch (_: Exception) {}
            try { renderer?.release() } catch (_: Exception) {}
            try { egl?.release() } catch (_: Exception) {}
            st = null
            camSurface = null
            renderer = null
            egl = null
            glDone.countDown()
        }
        glDone.await(2, TimeUnit.SECONDS)

        if (!eosLatch.await(4, TimeUnit.SECONDS)) {
            RecLog.log("$tag: кодер не завершился вовремя, закрываю файл принудительно")
            writer.close()
        }
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        try { inputSurface?.release() } catch (_: Exception) {}
        glThread.quitSafely()
        camThread.quitSafely()
        encThread.quitSafely()
        RecLog.log("$tag: остановлено")
    }

    companion object {
        const val FPS = 24
        const val BITRATE = 5_000_000
    }
}
